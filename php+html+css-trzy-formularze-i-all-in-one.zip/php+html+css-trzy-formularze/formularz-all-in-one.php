﻿<HTML><HEAD><META CHARSET="utf-8"> 
<META NAME="keywords" CONTENT="Formularz, Formularze, Kontrolki, Komponenty, PHP, HTML, CSS"> 
<META NAME="description" CONTENT="Przykład użycia formularzy oraz kontrolek na stronach WWW."> 
<LINK TYPE="text/css" REL="stylesheet" HREF="grafika/ini.css"> 
<LINK REL="shortcut icon" HREF="grafika/logo.ico"> 
<TITLE>Formularze WWW (all in one)</TITLE> 
</HEAD> 
<?php 
      echo "<BODY "; 
      if(isset($_POST['fkUkryty']) == true) { 
        if(trim($_POST['fkUkryty']) == "2") { 
           echo "onLoad=\"document.getElementById('EditNazwisko').focus();\">"; 
        } else if(trim($_POST['fkUkryty']) == "3") { 
                 echo "onLoad=\"document.getElementById('RokUr').focus();\">"; 
               } 
      } else { echo "onLoad=\"document.getElementById('EditImie').focus();\">"; } 
?> 
<CENTER> 
<DIV ID="strona"> 
    <DIV ID="naglowek">Formularze na stronach WWW (all in one)</DIV> 
    <DIV ID="zawartosc"> 
        <CENTER> 
        </BR></BR> 
        <FORM METHOD="post" ACTION=""> 
             <TABLE BORDER="0"> 
                    <?php 
                          if(isset($_POST['fkUkryty']) == true) { 
                            if(trim($_POST['fkUkryty']) == "2") { 
                              //Formularz 2 - Podaj nazwisko. 
                              echo " 
                                     <TR><TD>Nazwisko</TD> 
                                         <TD>:</TD> 
                                         <TD><INPUT TYPE=\"text\" ID=\"EditNazwisko\" NAME=\"fkEditNazwisko\" MAXLENGTH=\"50\" STYLE=\"width:400px; text-transform:capitalize; text-size:16pt;\"/> 
                                             <INPUT TYPE=\"hidden\" NAME=\"fkUkryty\" VALUE=\"3\"/> 
                                             <INPUT TYPE=\"hidden\" NAME=\"fkEditImie\" VALUE=\"".ucwords(strtolower(trim($_POST['fkEditImie'])))."\"/> 
                                         </TD> 
                                     </TR> 
                                   "; 
                            } else if(trim($_POST['fkUkryty']) == "3") { 
                                     //Formularz 3 - Podaj datę urodzenia. 
                                     echo " 
                                            <TR><TD>Rok urodzenia</TD> 
                                                <TD>:</TD> 
                                                <TD><SELECT ID=\"RokUr\" NAME=\"fkRokUr\" SIZE=\"1\" STYLE=\"width:60px; text-size:16pt;\"> 
                                                            <OPTION>&nbsp;</OPTION> 
                                          "; 
                                          $Rok = 0; $Rok = date("Y"); 
                                          $Sto = 0; $Sto = $Rok-120; 
                                          do { 
                                               echo "<OPTION>".($Rok--)."</OPTION>"; 
                                          } while($Rok > $Sto); 
                                     echo "         </SELECT> 
                                                    <INPUT TYPE=\"hidden\" NAME=\"fkUkryty\" VALUE=\"4\"/> 
                                                    <INPUT TYPE=\"hidden\" NAME=\"fkEditImie\" VALUE=\"".$_POST['fkEditImie']."\"/> 
                                                    <INPUT TYPE=\"hidden\" NAME=\"fkEditNazwisko\" VALUE=\"".ucwords(strtolower(trim($_POST['fkEditNazwisko'])))."\"/> 
                                                </TD> 
                                            </TR> 
                                          "; 
                                   } else if(trim($_POST['fkUkryty']) == "4") { 
                                            //Formularz 4 - Raport końcowy. 
                                            echo " 
                                                   <TR><TD COLSPAN=\"3\" STYLE=\"text-align:center; font-weight:bold;\">Raport końcowy</TD></TR> 
                                                   <TR><TD>Imię</TD> 
                                                       <TD>:</TD> 
                                                       <TD>".trim($_POST['fkEditImie'])."</TD> 
                                                   </TR> 
                                                   <TR><TD>Nazwisko</TD> 
                                                       <TD>:</TD> 
                                                       <TD>".$_POST['fkEditNazwisko']."</TD> 
                                                   </TR> 
                                                   <TR><TD>Rok urodzenia</TD> 
                                                       <TD>:</TD> 
                                                       <TD>".trim($_POST['fkRokUr'])."</TD> 
                                                   </TR> 
                                                 "; 
                                          } 
                          } else { 
                                   //Formularz 1 - Podaj imię. 
                                   echo " 
                                          <TR><TD>Imię</TD> 
                                              <TD>:</TD> 
                                              <TD><INPUT TYPE=\"text\" ID=\"EditImie\" NAME=\"fkEditImie\" MAXLENGTH=\"20\" STYLE=\"width:200px; text-transform:capitalize; text-size:16pt;\"/> 
                                                  <INPUT TYPE=\"hidden\" NAME=\"fkUkryty\" VALUE=\"2\"/> 
                                              </TD> 
                                          </TR> 
                                        "; 
                                 } 
                     ?> 
                   <TR><TD COLSPAN="3" ALIGN="right"> 
                           <?php 
                                 if(isset($_POST['fkUkryty']) == true) { 
                                   if((trim($_POST['fkUkryty']) == "2") || (trim($_POST['fkUkryty']) == "3")) { 
                                     //Formularz 2 i 3 - Nazwisko i Rok urodzenia. 
                                     echo " 
                                            <INPUT TYPE=\"submit\" ID=\"PrzyciskWykonaj1\" NAME=\"fkPrzyciskWykonaj1\" VALUE=\"Wprowadź\"/> 
                                            &nbsp;<INPUT TYPE=\"reset\" ID=\"PrzyciskWykonaj2\" NAME=\"fkPrzyciskWykonaj2\" VALUE=\"Wyczyść\"/> 
                                          "; 
                                   } else if(trim($_POST['fkUkryty']) == "4") { 
                                            //Formularz 4 - Raport końcowy. 
                                            echo "<INPUT TYPE=\"submit\" ID=\"PrzyciskWykonaj1\" NAME=\"fkPrzyciskWykonaj1\" VALUE=\"OK\"/>"; 
                                          } 
                                 } else { 
                                          //Formularz 1 - Imię. 
                                          echo " 
                                                 <INPUT TYPE=\"submit\" ID=\"PrzyciskWykonaj1\" NAME=\"fkPrzyciskWykonaj1\" VALUE=\"Wprowadź\"/> 
                                                 &nbsp;<INPUT TYPE=\"reset\" ID=\"PrzyciskWykonaj2\" NAME=\"fkPrzyciskWykonaj2\" VALUE=\"Wyczyść\"/> 
                                               "; 
                                        } 
                           ?></TD> 
                   </TR> 
             </TABLE> 
        </FORM> 
        </CENTER> 
    </DIV> 
    <DIV ID="stopka">Copyright (c)by Jan T. Biernat, 2019 rok.</DIV> 
</DIV> 
</CENTER> 
</BODY> 
</HTML> 