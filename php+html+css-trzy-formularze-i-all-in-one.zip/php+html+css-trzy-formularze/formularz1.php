﻿<HTML><HEAD><META CHARSET="utf-8"> 
<META NAME="keywords" CONTENT="Formularz, Formularze, Kontrolki, Komponenty, PHP, HTML, CSS"> 
<META NAME="description" CONTENT="Przykład użycia formularzy oraz kontrolek na stronach WWW."> 
<LINK TYPE="text/css" REL="stylesheet" HREF="grafika/ini.css"> 
<LINK REL="shortcut icon" HREF="grafika/logo.ico"> 
<TITLE>Formularze WWW</TITLE> 
</HEAD> 
<BODY onLoad="document.getElementById('EditImie').focus();"> 
<CENTER> 
<DIV ID="strona"> 
    <DIV ID="naglowek">Formularz 1 - Imię</DIV> 
    <DIV ID="zawartosc"> 
        <CENTER> 
        </BR></BR> 
        <FORM METHOD="post" ACTION="formularz2.php"> 
             <TABLE BORDER="0"> 
                    <TR><TD>Imię</TD> 
                        <TD>:</TD> 
                        <TD><INPUT TYPE="text" ID="EditImie" NAME="fkEditImie" MAXLENGTH="30" STYLE="width:200px; text-transform:capitalize; text-size:16pt;"/></TD> 
                    </TR> 
                    <TR><TD COLSPAN="3" ALIGN="right"> 
                                 <INPUT TYPE="submit" ID="PrzyciskWykonaj1" NAME="fkPrzyciskWykonaj1" VALUE="Wprowadź"/> 
                           &nbsp;<INPUT TYPE="reset" ID="PrzyciskWykonaj2" NAME="fkPrzyciskWykonaj2" VALUE="Wyczyść"/></TD> 
                    </TR> 
             </TABLE> 
        </FORM> 
        </CENTER> 
    </DIV> 
    <DIV ID="stopka">Copyright (c)by Jan T. Biernat, 2019 rok.</DIV> 
</DIV> 
</CENTER> 
</BODY> 
</HTML> 