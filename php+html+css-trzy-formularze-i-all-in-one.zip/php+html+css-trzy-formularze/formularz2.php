﻿<HTML><HEAD><META CHARSET="utf-8"> 
<META NAME="keywords" CONTENT="Formularz, Formularze, Kontrolki, Komponenty, PHP, HTML, CSS"> 
<META NAME="description" CONTENT="Przykład użycia formularzy oraz kontrolek na stronach WWW."> 
<LINK TYPE="text/css" REL="stylesheet" HREF="grafika/ini.css"> 
<LINK REL="shortcut icon" HREF="grafika/logo.ico"> 
<TITLE>Formularze WWW</TITLE> 
</HEAD> 
<BODY onLoad="document.getElementById('EditNazwisko').focus();"> 
<CENTER> 
<DIV ID="strona"> 
    <DIV ID="naglowek">Formularz 2 - Nazwisko</DIV> 
    <DIV ID="zawartosc"> 
        <CENTER> 
        </BR></BR> 
        <FORM METHOD="post" ACTION="formularz3.php"> 
             <TABLE BORDER="0"> 
                    <TR><TD>Nazwisko</TD> 
                        <TD>:</TD> 
                        <TD><INPUT TYPE="text" ID="EditNazwisko" NAME="fkEditNazwisko" MAXLENGTH="50" STYLE="width:400px; text-transform:capitalize; text-size:16pt;"/></TD> 
                    </TR> 
                    <TR><TD COLSPAN="3" ALIGN="right"> 
                                 <INPUT TYPE="submit" ID="PrzyciskWykonaj1" NAME="fkPrzyciskWykonaj1" VALUE="Wprowadź"/> 
                           &nbsp;<INPUT TYPE="reset" ID="PrzyciskWykonaj2" NAME="fkPrzyciskWykonaj2" VALUE="Wyczyść"/></TD> 
                    </TR> 
             </TABLE> 
             <!-- Ukryte informacje dla programu. --> 
             <INPUT TYPE="hidden" NAME="fkEditImie" VALUE="<?php echo ucwords(strtolower(trim($_POST['fkEditImie']))); ?>"> 
        </FORM> 
        </CENTER> 
    </DIV> 
    <DIV ID="stopka">Copyright (c)by Jan T. Biernat, 2019 rok.</DIV> 
</DIV> 
</CENTER> 
</BODY> 
</HTML> 