﻿<HTML><HEAD><META CHARSET="utf-8"> 
<META NAME="keywords" CONTENT="Formularz, Formularze, Kontrolki, Komponenty, PHP, HTML, CSS"> 
<META NAME="description" CONTENT="Przykład użycia formularzy oraz kontrolek na stronach WWW."> 
<LINK TYPE="text/css" REL="stylesheet" HREF="grafika/ini.css"> 
<LINK REL="shortcut icon" HREF="grafika/logo.ico"> 
<TITLE>Formularze WWW</TITLE> 
</HEAD> 
<BODY onLoad="document.getElementById('RokUr').focus();"> 
<CENTER> 
<DIV ID="strona"> 
    <DIV ID="naglowek">Formularz 3 - Rok urodzenia</DIV> 
    <DIV ID="zawartosc"> 
        <CENTER> 
        </BR></BR> 
        <FORM METHOD="post" ACTION="formularz4-raport.php"> 
             <TABLE BORDER="0"> 
                    <TR><TD>Rok urodzenia</TD> 
                        <TD>:</TD> 
                        <TD><SELECT ID="RokUr" NAME="fkRokUr" SIZE="1" STYLE="width:60px; text-size:16pt;"> 
                                    <OPTION>&nbsp;</OPTION> 
                                    <?php 
                                          $Rok = 0; $Rok = date("Y"); 
                                          $Sto = 0; $Sto = $Rok-120; 
                                          do { 
                                               echo "<OPTION>".($Rok--)."</OPTION>"; 
                                          } while($Rok > $Sto); 
                                    ?> 
                            </SELECT> 
                        </TD> 
                    </TR> 
                    <TR><TD COLSPAN="3" ALIGN="right"> 
                                 <INPUT TYPE="submit" ID="PrzyciskWykonaj1" NAME="fkPrzyciskWykonaj1" VALUE="Wprowadź"/> 
                           &nbsp;<INPUT TYPE="reset" ID="PrzyciskWykonaj2" NAME="fkPrzyciskWykonaj2" VALUE="Wyczyść"/></TD> 
                    </TR> 
             </TABLE> 
             <!-- Ukryte informacje dla programu. --> 
             <INPUT TYPE="hidden" NAME="fkEditImie" VALUE="<?php echo $_POST['fkEditImie']; ?>"> 
             <INPUT TYPE="hidden" NAME="fkEditNazwisko" VALUE="<?php echo ucwords(strtolower(trim($_POST['fkEditNazwisko']))); ?>"> 
        </FORM> 
        </CENTER> 
    </DIV> 
    <DIV ID="stopka">Copyright (c)by Jan T. Biernat, 2019 rok.</DIV> 
</DIV> 
</CENTER> 
</BODY> 
</HTML> 