﻿<HTML><HEAD><META CHARSET="utf-8"> 
<META NAME="keywords" CONTENT="Formularz, Formularze, Kontrolki, Komponenty, PHP, HTML, CSS"> 
<META NAME="description" CONTENT="Przykład użycia formularzy oraz kontrolek na stronach WWW."> 
<LINK TYPE="text/css" REL="stylesheet" HREF="grafika/ini.css"> 
<LINK REL="shortcut icon" HREF="grafika/logo.ico"> 
<TITLE>Formularze WWW</TITLE> 
</HEAD> 
<BODY> 
<CENTER> 
<DIV ID="strona"> 
    <DIV ID="naglowek">Formularz 4 - Raport</DIV> 
    <DIV ID="zawartosc"> 
        <CENTER> 
        </BR></BR> 
        <FORM METHOD="post" ACTION="formularz1.php"> 
             <TABLE BORDER="0"> 
                    <TR><TD COLSPAN="3" STYLE="text-align:center; font-weight:bold;">Raport końcowy</TD></TR> 
                    <TR><TD>Imię</TD> 
                        <TD>:</TD> 
                        <TD><?php echo trim($_POST['fkEditImie']); ?></TD> 
                    </TR> 
                    <TR><TD>Nazwisko</TD> 
                        <TD>:</TD> 
                        <TD><?php echo $_POST['fkEditNazwisko']; ?></TD> 
                    </TR> 
                    <TR><TD>Rok urodzenia</TD> 
                        <TD>:</TD> 
                        <TD><?php echo trim($_POST['fkRokUr']); ?></TD> 
                    </TR> 
                    <TR><TD COLSPAN="3" ALIGN="right"> 
                            <INPUT TYPE="submit" ID="PrzyciskWykonaj1" NAME="fkPrzyciskWykonaj1" VALUE="OK"/></TD> 
                    </TR> 
             </TABLE> 
        </FORM> 
        </CENTER> 
    </DIV> 
    <DIV ID="stopka">Copyright (c)by Jan T. Biernat, 2019 rok.</DIV> 
</DIV> 
</CENTER> 
</BODY> 
</HTML> 