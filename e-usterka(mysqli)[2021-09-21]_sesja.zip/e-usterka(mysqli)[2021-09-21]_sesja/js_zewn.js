﻿//JavaScript - Plik zewnętrzny. 
//Copyright (c)by Jan T. Biernat 
function DzisiajJest() { 
  //DzisiajJest - Podaje bieżącą datę na podstawie systemowego zegara czasu rzeczywistego. 
    const NazwaMiesiaca = ["stycznia", "lutego", "marca", "kwietnia", "maja", 
                           "czerwca", "lipca", "sierpnia", "września", 
                           "października", "listopada", "grudnia"]; 
    var data = new Date(); //Utworzenie obiektu Data. 
    document.getElementById("InfDzisiajJest").innerHTML = data.getDate()+" "+NazwaMiesiaca[data.getMonth()]+" "+data.getFullYear()+"r.&nbsp;";
} 
//Koniec. 