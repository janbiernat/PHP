﻿<?php 
/*--== Biblioteka (eusterka) dla PHP ==-- 
  Copyright (c)by Jan T. Biernat 
----------------------------------------- 
By móc korzystać z biblioteki "eusterka", to 
należy ją podłączyć w pliku o rozszerzeniu PHP 
za pomocą instrukcji "include_once". 
Na przykład: "<?php include_once('eusterka.php'); ?>". 
Od tego momentu można wywoływać funkcje z biblioteki. 
*/ 
//Deklaracja stałych. 
  define("SG_infBrakDanych", "<FONT CLASS=\"tekst20-inf\">Brak zgłoszonych usterek!</FONT> "); 
  define("SG_BazaUsterka", "usterka"); 
//Funkcje. 
function UzytkownikTyp($Typ = 0) { 
  if($Typ == 0) { return "Użytkownik standardowy"; } else { return "Administrator platformy E-Usterka"; } 
} 
function ZnakiSprawdz($SQL_Polacz, $Str = "") { 
  $Str = trim($Str); 
  if($Str != "") { 
    $Str = stripcslashes($Str);                           //1. 
    $Str = htmlspecialchars($Str);                        //2. 
    @mysqli_set_charset($SQL_Polacz,"utf8"); 
    $Str = @mysqli_real_escape_string($SQL_Polacz, $Str); //3. 
  } 
  return $Str; 
/* 
  Legenda: 
  1) Funkcja STRIPCSLASHES Usuwa znak "\". 
  2) Funkcja HTMLSPECIALCHARS konwertuje zdefiniowane znaki HTML. 
     Zdefiniowane znaki to: 
     a) & (logiczne i) staje się znakiem &. 
     b) „ (podwójny cudzysłów) staje się znakiem ". 
     c) ' (pojedynczy cudzysłów) zmienia się w '. 
     d) < (mniej niż) staje się <. 
     e) > (większe niż) staje się >. 
    Konwersję wykonujemy po to, by uniemożliwić interpretacje tych znaków 
    jako fragmentu HTML. 
  3) Funkcja MYSQLI_REAL_ESCAPE_STRING dokonuje zmiany znaczenia znaków specjalnych 
     w ciągu do użycia w zapytaniu SQL. Bierze przy tym pod uwagę zestaw znaków przy 
     połączeniu. 
 */ 
} 
// 
//======== 
// 
function bdPobierzDaneSLO($BazaSLO = "", $PoleSLO = "") { 
  //bdPobierzDaneSLO - Pobiera dane z bazy i umieszcza w kodzie HTML. 
    $SQL_Polacz = ""; 
    $SQL_Query = ""; 
    $SQL_ListaSLO = ""; 
    $Licznik = 0; 
  //Formatuj parametry. 
    $BazaSLO = htmlspecialchars(trim($BazaSLO)); 
    $PoleSLO = htmlspecialchars(trim($PoleSLO)); 
    if(($BazaSLO != "") && ($PoleSLO != "")) { 
      $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); 
      if($SQL_Polacz) { 
        @mysqli_set_charset($SQL_Polacz,"utf8"); 
        //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
        if(@mysqli_select_db($SQL_Polacz, SG_BazaUsterka)) { 
          $SQL_Query = @mysqli_query($SQL_Polacz, "SELECT DISTINCT `".$PoleSLO."` FROM `".$BazaSLO."` ORDER BY `".$PoleSLO."` ASC"); 
          if($SQL_Query) { 
            if(@mysqli_num_rows($SQL_Query) > 0) { 
              while($SQL_ListaSLO = @mysqli_fetch_array($SQL_Query)) { 
                echo "\n<OPTION VALUE=\"".$SQL_ListaSLO[$Licznik]."\" />"; 
              } 
              $Licznik++; 
            } 
          } 
        } 
        @mysqli_close($SQL_Polacz); //Zamknięcie połączenia z bazą. 
      } 
    } 
  return $Licznik; 
} 
//======== 
function bdWyswietlDaneUzytkownika($LoginU = "", $LoginH = "") { 
  //Deklaracja zmiennych tekstowych. 
    $SQL_Polacz = ""; 
    $SQL_Query = ""; 
    $SQL_Konto = ""; 
    $SQL_Uzytkownik = ""; 
  //Parametry funkcji. 
    $LoginU = htmlspecialchars(trim($LoginU)); 
    $LoginH = htmlspecialchars(trim($LoginH)); 
  //Wyszukanie danych. 
    if(($LoginU != "") && ($LoginH != "")) { 
      //Połączenie z bazą. 
        $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); 
        if($SQL_Polacz) { 
          @mysqli_set_charset($SQL_Polacz,"utf8"); 
          //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
          if(@mysqli_select_db($SQL_Polacz, SG_BazaUsterka)) { 
            $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                      SELECT DISTINCT `konto_id`, 
                                                                      `konto_login`, 
                                                                      `konto_haslo`, 
                                                                      `konto_in`, 
                                                                      `konto_mail`, 
                                                                      `konto_uprawnienia` 
                                                      FROM `konto` 
                                                      WHERE `konto_login` = '".ZnakiSprawdz($SQL_Polacz, $LoginU)."' 
                                                      AND `konto_haslo` = '".ZnakiSprawdz($SQL_Polacz, $LoginH)."' 
                                                    "); 
            if($SQL_Query) { 
              if(@mysqli_num_rows($SQL_Query) > 0) { 
                while($SQL_Konto = @mysqli_fetch_array($SQL_Query)) { 
                  $SQL_Uzytkownik = trim($SQL_Konto[3]); 
                  echo " 
                         <TABLE BORDER=\"0\"> 
                                <TR><TD>Zalogowany</TD> 
                                    <TD>:</TD> 
                                    <TD>".trim($SQL_Konto[1])." (".$SQL_Uzytkownik.")</TD> 
                                </TR> 
                                <TR><TD>Opis</TD> 
                                    <TD>:</TD> 
                                    <TD>".UzytkownikTyp($SQL_Konto[5])."</TD> 
                                </TR> 
                         </TABLE><BR/> 
                       "; 
                } 
              } 
            } 
          } 
          @mysqli_close($SQL_Polacz); //Zamknięcie połączenia z bazą. 
        } 
    } 
  return $SQL_Uzytkownik; 
} 
//======== 
?> 