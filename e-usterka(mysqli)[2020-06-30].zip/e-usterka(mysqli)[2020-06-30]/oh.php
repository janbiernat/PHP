﻿<HTML><HEAD><META CHARSET="utf-8" /> 
<META NAME="keywords" CONTENT="eUsterki, e-Usterki, Usterki, Naprawa, Komputery, Serwis, Monitory, Klawiatury" /> 
<META NAME="description" CONTENT="Naprawa zgłoszonych usterek oraz pomoc w obsłudze programów." /> 
<LINK REL="shortcut icon" HREF="graf/eusterka.ico" /> 
<LINK REL="stylesheet" TYPE="text/css" HREF="graf/style.css" /> 
<SCRIPT TYPE="text/javascript" SRC="js_zewn.js"></SCRIPT> 
<TITLE>eUsterki (c)by Jan T. Biernat</TITLE> 
</HEAD> 
<?php 
  //Deklaracja stałych. 
    define("InfoNoweHaslo", "<BR/><BR/><A CLASS=\"link_menu0\" HREF=\"uz-zh1.php\">Ponów ustawienie nowego hasła</A>&nbsp;<FONT CLASS=\"tekst13\">lub</FONT>"); 
  //Deklaracja zmiennych tekstowych. 
    $SQL_Polacz = ""; 
    $SQL_Query = ""; 
    $SQL_Konto = ""; 
    $SQL_Aktualizuj = ""; 
    $FormularzInfo = ""; 
    $SQL_CzyJest = 0; 
  //Czy formularz jest uzupełniony? 
    if((isset($_POST['fkBladUstaw']) == true) 
    &&(strtolower($_POST['fkBladUstaw']) == "ustaw") 
    && (trim($_POST['fkBladU']) != "") 
    && (trim($_POST['fkBladP']) != "") 
    && (trim($_POST['fkBladH1']) != "") 
    && (trim($_POST['fkBladH2']) != "") 
    && (trim($_POST['fkBladW']) != "") 
    && ($_POST['fkBladDobrze'] != "")) { 
      if(sha1($_POST['fkBladW']) == $_POST['fkBladDobrze']) { 
        $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); 
        if($SQL_Polacz) { 
          @mysqli_set_charset($SQL_Polacz,"utf8"); 
          //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
          if(@mysqli_select_db($SQL_Polacz, "usterka")) { 
            $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                      SELECT DISTINCT `konto_id`, 
                                                                      `konto_login`, 
                                                                      `konto_haslo`, 
                                                                      `konto_in`, 
                                                                      `konto_mail`, 
                                                                      `konto_uprawnienia` 
                                                      FROM `konto` 
                                                      WHERE `konto_login` = '".htmlspecialchars($_POST['fkBladU'])."' 
                                                      AND `konto_mail` = '".htmlspecialchars($_POST['fkBladP'])."' 
                                                    "); 
            if($SQL_Query) { 
              if(@mysqli_num_rows($SQL_Query) > 0) { 
                $SQL_CzyJest = 1; 
                while($SQL_Konto = @mysqli_fetch_array($SQL_Query)) { 
                  //Tu wpisz kod. 
                } 
              } 
            } 
            //Ustaw nowe hasło. 
              if($SQL_CzyJest == 1) { 
                //Wykonaj poniższe instrukcje, gdy użytkownik zostanie odnaleziony w bazie. 
                  if($_POST['fkBladH1'] == $_POST['fkBladH2']) { 
                    //Jeżeli podane hasła są takie same, to wykonaj poniższy kod. 
                      $SQL_Aktualizuj = " 
                                          UPDATE `konto` 
                                          SET `konto_haslo` = '".sha1(htmlspecialchars(trim($_POST['fkBladH1'])))."' 
                                          WHERE `konto_login` = '".htmlspecialchars($_POST['fkBladU'])."' 
                                          AND `konto_mail` = '".htmlspecialchars($_POST['fkBladP'])."' 
                                        "; 
                      @mysqli_query($SQL_Polacz, $SQL_Aktualizuj); 
                      header("Location: index.php"); //Przejście do strony logowania. 
                      exit(); //Zamknięcie strony. 
                  } else { $FormularzInfo = "Podane hasła nie są takie same!"; } 
              } else { $FormularzInfo = "Brak takiego użytkownika!"; } 
          } 
        } 
      } else { $FormularzInfo = "Błędny wynik mnożenia!"; } 
    } else { $FormularzInfo = "Formularz jest pusty!"; } 
 ?> 
<BODY ONLOAD="DzisiajJest();"> 
  <DIV ID="strona"> 
     <DIV ID="naglowek"> 
          <DIV ID="naglowek-p1"><IMG SRC="graf/nag-eusterka.gif" /></DIV> 
          <DIV ID="naglowek-p2"> 
               <TABLE BORDER="0" CLASS="naglowek-tabela"> 
                      <TR CLASS="naglowek-tabela-komorka"><TD STYLE="width:495px; text-align:right;">&nbsp;</TD></TR> 
                      <TR CLASS="naglowek-tabela-komorka"><TD ID="InfDzisiajJest"  STYLE="width:495px; text-align:right;"></TD></TR> 
               </TABLE> 
          </DIV> 
     </DIV> 
     <DIV ID="naglowek-linia-pozioma"><IMG STYLE="width:1024px;" SRC="graf/nag-linia-pozioma.gif" /></DIV> 
     <DIV ID="zawartosc"> 
          <A HREF="index.php"><IMG CLASS="strzalka-w-lewo" SRC="graf/strzalka-w-lewo.gif" /></A><BR/> 
          <CENTER> 
          <FONT CLASS="logowanie-tytul">Nie pamiętam hasła</FONT><BR/><BR/> 
          <FORM METHOD="post" ACTION=""> 
                <TABLE BORDER="0"> 
                       <TR><TD COLSPAN="3">Proszę uzupełnić formularz, a nowe hasło zostanie ustawione.</TD></TR> 
                       <TR><TD COLSPAN="3">&nbsp;</TD></TR> 
                       <TR><TD>Nazwa użytkownika</TD> 
                           <TD>&nbsp;:&nbsp;</TD> 
                           <TD><INPUT TYPE="text" CLASS="logowanie" NAME="fkBladU" ID="BladU" PLACEHOLDER="" MAXLENGTH="25" SIZE="25" VALUE="" AUTOFOCUS /></TD> 
                       </TR> 
                       <TR><TD>Adres e-mail</TD> 
                           <TD>&nbsp;:&nbsp;</TD> 
                           <TD><INPUT TYPE="email" CLASS="logowanie" NAME="fkBladP" ID="BladP" PLACEHOLDER="" MAXLENGTH="60" SIZE="60" VALUE="" /></TD> 
                       </TR> 
                       <TR><TD COLSPAN="3">&nbsp;</TD></TR> 
                       <TR><TD>Nowe hasło</TD> 
                           <TD>&nbsp;:&nbsp;</TD> 
                           <TD><INPUT TYPE="password" CLASS="logowanie" NAME="fkBladH1" ID="BladH1" PLACEHOLDER="" MAXLENGTH="33" SIZE="33" VALUE="" /> 
                               <SUP><A CLASS="dymek-pytajnik" HREF="inf-dh.htm" TITLE="W jaki sposób budować bezpieczne hasła?">?</A></SUP></TD> 
                       </TR> 
                       <TR><TD>Potwierdź hasło</TD> 
                           <TD>&nbsp;:&nbsp;</TD> 
                           <TD><INPUT TYPE="password" CLASS="logowanie" NAME="fkBladH2" ID="BladH2" PLACEHOLDER="" MAXLENGTH="33" SIZE="33" VALUE="" /></TD> 
                       </TR> 
                       <TR><TD COLSPAN="3">&nbsp;</TD></TR> 
                       <TR><TD STYLE="text-align:right;">Ile jest <?php 
                                                                        $Jeden = 0; $Jeden = rand(0, 10); 
                                                                        $Dwa = 0; $Dwa = rand(0, 10); 
                                                                        echo $Jeden." * ".$Dwa; 
                                                                   ?> 
                               <INPUT TYPE="hidden" NAME="fkBladDobrze" ID="Dobrze" VALUE="<?php echo sha1(($Jeden*$Dwa)); ?>" /> 
                           </TD> 
                           <TD>&nbsp;=&nbsp;</TD> 
                           <TD><INPUT TYPE="number" CLASS="tm-odp" NAME="fkBladW" ID="BladW" PLACEHOLDER="" MAXLENGTH="3" SIZE="3" VALUE="" /></TD> 
                       </TR> 
                       <TR><TD COLSPAN="3" STYLE="text-align:right;"><FONT CLASS="tekst13-blad"><?php echo $FormularzInfo; ?></FONT></TD></TR> 
                       <TR><TD COLSPAN="3">&nbsp;</TD></TR> 
                       <TR><TD COLSPAN="3" ALIGN="right"> 
                               <INPUT TYPE="reset" VALUE="Wyczyść" /> 
                               &nbsp;<INPUT TYPE="submit" NAME="fkBladUstaw" ID="BladUstaw" onClick="" VALUE="Ustaw" />&nbsp;</TD> 
                       </TR> 
                </TABLE> 
          </FORM><BR/> 
          </CENTER> 
     </DIV> 
     <DIV ID="stopka">eUsterki (c)by Jan T. Biernat</DIV> 
  </DIV> 
</BODY> 
</HTML> 