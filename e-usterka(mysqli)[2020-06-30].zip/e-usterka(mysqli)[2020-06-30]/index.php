﻿<HTML><HEAD><META CHARSET="utf-8" /> 
<META NAME="keywords" CONTENT="eUsterki, e-Usterki, Usterki, Naprawa, Komputery, Serwis, Monitory, Klawiatury" /> 
<META NAME="description" CONTENT="Naprawa zgłoszonych usterek oraz pomoc w obsłudze programów." /> 
<LINK REL="shortcut icon" HREF="graf/eusterka.ico" /> 
<LINK REL="stylesheet" TYPE="text/css" HREF="graf/style.css" /> 
<SCRIPT TYPE="text/javascript" SRC="js_zewn.js"></SCRIPT> 
<TITLE>eUsterki (c)by Jan T. Biernat</TITLE> 
</HEAD> 
<?php 
  include_once('eusterka.php'); 
  session_start(); 
  $_SESSION['ip'] = $_SERVER['REMOTE_ADDR']; 
  $_SESSION['login_nr'] = 0; 
  $_SESSION['login'] = ""; 
  $_SESSION['password'] = ""; 
  $_SESSION['uprawnienia'] = ""; 
  //Deklaracja zmiennych. 
    $SQL_Polacz = ""; 
    $SQL_Query = ""; 
    $SQL_Konto = ""; 
  //Połączenie z bazą. 
    if((isset($_POST['fkZaloguj']) == true) 
    &&(strtolower($_POST['fkZaloguj']) == "zaloguj") 
    && (trim($_POST['fkUzytkownik']) != "") 
    && (trim($_POST['fkHaslo']) != "")) { 
      $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); 
      if($SQL_Polacz) { 
        @mysqli_set_charset($SQL_Polacz,"utf8"); 
        //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
        if(@mysqli_select_db($SQL_Polacz, SG_BazaUsterka)) { 
          $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                    SELECT DISTINCT `konto_login`, 
                                                                    `konto_haslo`, 
                                                                    `konto_uprawnienia` 
                                                    FROM `konto` 
                                                    WHERE `konto_login` = '".ZnakiSprawdz($SQL_Polacz, $_POST['fkUzytkownik'])."' 
                                                    AND `konto_haslo` = '".sha1(ZnakiSprawdz($SQL_Polacz, $_POST['fkHaslo']))."' 
                                                  "); 
          if($SQL_Query) { 
            if(@mysqli_num_rows($SQL_Query) > 0) { 
              $_SESSION['login_nr'] = 1; 
              while($SQL_Konto = @mysqli_fetch_array($SQL_Query)) { 
                $_SESSION['login'] = $SQL_Konto[0]; 
                $_SESSION['password'] = $SQL_Konto[1]; 
                $_SESSION['uprawnienia'] = $SQL_Konto[2]; 
              } 
              if($_SESSION['uprawnienia'] == 0) { header("Location: us-z.php"); } else { header("Location: ua-lu.php"); } 
              exit(); 
            } 
          } 
        } 
        @mysqli_close($SQL_Polacz); 
      } 
    } 
 ?> 
<BODY ONLOAD="DzisiajJest();"> 
      <DIV ID="strona"> 
           <DIV ID="naglowek"> 
                <DIV ID="naglowek-p1"><IMG SRC="graf/nag-eusterka.gif" /></DIV> 
                <DIV ID="naglowek-p2"> 
                     <TABLE BORDER="0" CLASS="naglowek-tabela"> 
                            <TR CLASS="naglowek-tabela-komorka"><TD STYLE="width:495px; text-align:right;">&nbsp;</TD></TR> 
                            <TR CLASS="naglowek-tabela-komorka"><TD ID="InfDzisiajJest"  STYLE="width:495px; text-align:right;"></TD></TR> 
                     </TABLE> 
                </DIV> 
           </DIV> 
           <DIV ID="naglowek-linia-pozioma"><IMG STYLE="width:1024px;" SRC="graf/nag-linia-pozioma.gif" /></DIV> 
           <DIV ID="zawartosc"> 
                <BR/> 
                <CENTER> 
                <FONT CLASS="logowanie-tytul">Logowanie</FONT><BR/><BR/> 
                <FORM METHOD="post" ACTION=""> 
                      <INPUT TYPE="hidden" NAME="fkTT" VALUE=""> 
                      <TABLE BORDER="0"> 
                             <TR><TD>Nazwa użytkownika</TD> 
                                 <TD>&nbsp;:&nbsp;</TD> 
                                 <TD><INPUT TYPE="text" CLASS="logowanie" NAME="fkUzytkownik" ID="Uzytkownik" PLACEHOLDER="" MAXLENGTH="25" SIZE="25" VALUE="" AUTOFOCUS /></TD> 
                             </TR> 
                             <TR><TD>Hasło</TD> 
                                 <TD>&nbsp;:&nbsp;</TD> 
                                 <TD><INPUT TYPE="password" CLASS="logowanie" NAME="fkHaslo" ID="Haslo" PLACEHOLDER="" MAXLENGTH="33" SIZE="33" VALUE="" /></TD> 
                             </TR> 
                             <?php 
                                   if((isset($_POST['fkZaloguj']) == true) 
                                   &&(strtolower($_POST['fkZaloguj']) == "zaloguj") 
                                   && (trim($_POST['fkUzytkownik']) != "") 
                                   && (trim($_POST['fkHaslo']) != "")) { 
                                     if($_SESSION['login_nr'] == 0) { 
                                       echo "<TR><TD COLSPAN=\"3\" STYLE=\"text-align:right;\"><FONT CLASS=\"tekst13-blad\">Błąd przy logowaniu!</FONT></TD></TR>"; 
                                     } 
                                   } 
                              ?> 
                             <TR><TD COLSPAN="3">&nbsp;</TD></TR> 
                             <TR><TD COLSPAN="3" ALIGN="right"> 
                                     <INPUT TYPE="reset" VALUE="Wyczyść" /> 
                                     &nbsp;<INPUT TYPE="submit" NAME="fkZaloguj" ID="Zaloguj" onClick="" VALUE="Zaloguj" />&nbsp; 
                                 </TD> 
                             </TR> 
                             <TR><TD COLSPAN="3">&nbsp;</TD></TR> 
                             <TR><TD COLSPAN="3" STYLE="text-align:right; font-size:13px; color:blue;"><A CLASS="link_menu0" HREF="oh.php" TITLE="Pomoc w odzyskaniu hasła do platformy e Usterki.">Nie pamiętam hasła</A>&nbsp;</TD></TR> 
                      </TABLE> 
                </FORM> 
                </CENTER> 
           </DIV> 
           <DIV ID="stopka">eUsterki (c)by Jan T. Biernat</DIV> 
      </DIV> 
</BODY> 
</HTML> 