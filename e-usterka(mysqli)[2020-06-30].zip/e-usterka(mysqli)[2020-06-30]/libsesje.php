﻿<?php 
/*--== Biblioteka (libSesje) dla PHP ==-- 
  Copyright (c)by Jan T. Biernat 
----------------------------------------- 
By móc korzystać z biblioteki "libSesje", to 
należy ją podłączyć w pliku o rozszerzeniu PHP 
za pomocą instrukcji "include_once". 
Na przykład: "<?php include_once('libsesje.php'); ?>". 
Od tego momentu można wywoływać funkcje z biblioteki. 
*/ 
//Deklaracja stałych globalnych. 
  define('BD_NazwaBazy', "usterka"); //Stała "BD_NazwaBazy" przechowuje nazwę bazy. 
  define('BD_NazwaTabeliSesji', "sesja"); //Stała "BD_NazwaTabeliSesji" przechowuje nazwę tabeli z informacjami o sesjach. 
//-- 
//Funkcje. 
function UsuwanieSesji($StronaLogownia = "index.php") { 
  //UsuwanieSesji - Usuwanie sesji wraz z usunięciem wszystkich zmiennych występujących w sesji. 
    $_SESSION = array(); //Usunięcie wszystkich zmiennych występujących w sesji. 
    header("Location: ".strtolower(htmlspecialchars(trim($StronaLogownia)))); //Przejście do strony logowania. 
    exit(); //Zamknięcie strony. 
} 
function bdSesjaSzukaj($SesjaLogin = "") { 
  //bdSesjaSzukaj - Wyszukaj zapisaną w bazie danych sesję. 
    $SQL_Polacz = ""; 
    $SQL_Query = ""; 
    $SesjaCzyZapisana = 0; 
  //Czy parametr funkcji posiada jakieś dane? 
    $SesjaLogin = htmlspecialchars(trim($SesjaLogin)); 
    if($SesjaLogin != "") { 
      $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); //Połączenie z serwerem baz danych. 
      if($SQL_Polacz) { 
        @mysqli_set_charset($SQL_Polacz,"utf8"); 
        //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
        if(@mysqli_select_db($SQL_Polacz, BD_NazwaBazy)) { 
          $SQL_Query = @mysqli_query($SQL_Polacz, "SELECT DISTINCT `sesja_login` FROM `".BD_NazwaTabeliSesji."` 
                                                   WHERE `sesja_login` = '".$SesjaLogin."'"); 
          if($SQL_Query) { 
            if(@mysqli_num_rows($SQL_Query) > 0) { $SesjaCzyZapisana = 1; } 
          } 
        } 
        @mysqli_close($SQL_Polacz); 
      } 
    } 
  return $SesjaCzyZapisana; 
} 
function bdSesjaDodaj($SesjaLogin = "") { 
  //bdSesjaDodaj - Dodaj informacje o nowej sesji. 
    $SQL_Polacz = ""; 
    $SQL_Query1 = ""; 
    $SQL_Query2 = ""; 
    $SesjaCzyJest = 0; 
  //Czy parametr funkcji posiada jakieś dane? 
    $SesjaLogin = htmlspecialchars(trim($SesjaLogin)); 
    if($SesjaLogin != "") { 
      $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); //Połączenie z serwerem baz danych. 
      if($SQL_Polacz) { 
        @mysqli_set_charset($SQL_Polacz,"utf8"); 
        //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
        if(@mysqli_select_db($SQL_Polacz, BD_NazwaBazy)) { 
          $SQL_Query1 = @mysqli_query($SQL_Polacz, "SELECT DISTINCT `sesja_login` FROM `".BD_NazwaTabeliSesji."` 
                                                    WHERE `sesja_login` = '".$SesjaLogin."'"); 
          if($SQL_Query1) { 
            if(@mysqli_num_rows($SQL_Query1) > 0) { $SesjaCzyJest = 1; } 
          } 
          //Jeżeli LOGIN'u o podanej nazwie brak w bazie, to wpisz go do bazy. 
            if($SesjaCzyJest == 0) { 
              $SQL_Query2 = "INSERT INTO `".BD_NazwaTabeliSesji."` SET `sesja_login` = '".$SesjaLogin."'"; 
              @mysqli_query($SQL_Polacz, $SQL_Query2); 
            } 
        } 
        @mysqli_close($SQL_Polacz); 
      } 
      if($SesjaCzyJest == 0) { return 'Zapisano'; } else { return 'Już jest'; } 
    } else { return '?'; } 
} 
function bdSesjaUsun($SesjaLogin = "") { 
  //bdSesjaUsun - Usuń wybranego użytkownika z bazy (tabeli) dotyczącej sesji. 
    $SQL_Polacz = ""; 
    $SQL_Query = ""; 
    $SesjaCzyJest = 0; 
  //Czy parametr funkcji posiada jakieś dane? 
    $SesjaLogin = htmlspecialchars(trim($SesjaLogin)); 
    if($SesjaLogin != "") { 
      $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); //Połączenie z serwerem baz danych. 
      if($SQL_Polacz) { 
        @mysqli_set_charset($SQL_Polacz,"utf8"); 
        //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
        if(@mysqli_select_db($SQL_Polacz, BD_NazwaBazy)) { 
          $SQL_Query = @mysqli_query($SQL_Polacz, "SELECT DISTINCT `sesja_login` FROM `".BD_NazwaTabeliSesji."` 
                                                    WHERE `sesja_login` = '".$SesjaLogin."'"); 
          if($SQL_Query) { 
            if(@mysqli_num_rows($SQL_Query) > 0) { $SesjaCzyJest = 1; } 
          } 
          //Jeżeli LOGIN'u o podanej nazwie brak w bazie, to wpisz go do bazy. 
            if($SesjaCzyJest == 1) { 
              @mysqli_query($SQL_Polacz, "DELETE FROM `".BD_NazwaTabeliSesji."` WHERE `sesja_login` = '".$SesjaLogin."'"); 
              return "Usunięto"; 
            } else { return "Brak rekordu"; } 
        } 
        @mysqli_close($SQL_Polacz); 
      } else { return '?'; } 
    } else { return "?"; } 
} 
function bdSesjaUsunWszystko() { 
  //bdSesjaUsunWszystko - Usuń wszystkie dane z tabeli dotyczącej sesji. 
    $SQL_Polacz = ""; 
    $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); //Połączenie z serwerem baz danych. 
    if($SQL_Polacz) { 
      @mysqli_set_charset($SQL_Polacz,"utf8"); 
      //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
      if(@mysqli_select_db($SQL_Polacz, BD_NazwaBazy)) { 
        @mysqli_query($SQL_Polacz, "DELETE FROM `".BD_NazwaTabeliSesji."`"); 
      } 
      @mysqli_close($SQL_Polacz); 
      return "Usunięto wszystko!"; 
    } else { return '?'; } 
} 
//--== Sesje ==-- 
?> 