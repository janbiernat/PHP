﻿<?php 
  //Baza danych: Usuwanie sesji. 
    $SQL_Polacz = ""; 
    $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); //Połączenie z serwerem baz danych. 
    if($SQL_Polacz) { 
      @mysqli_set_charset($SQL_Polacz,"utf8"); 
      //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
      if(@mysqli_select_db($SQL_Polacz, "usterka")) { @mysqli_query($SQL_Polacz, "DELETE FROM `sesja`"); } 
      @mysqli_close($SQL_Polacz); 
      echo "Usunięto wszystko!"; 
    } else { echo 'BŁĄD -?Brak połączenia z serwerem baz danych!'; } 
 ?> 