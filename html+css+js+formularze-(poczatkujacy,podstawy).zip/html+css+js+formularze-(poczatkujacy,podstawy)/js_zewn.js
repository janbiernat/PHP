﻿//JavaScript - Plik zewnętrzny. 
function mat_potega() { 
  var T = ""; T = document.getElementById('fkEdit').value; 
  if(T.trim() != "") { 
    /*Jeżeli wprowadzono liczbę w kontrolce/komponencie o nazwie "fkEdit", to 
      wykonaj poniższy kod. W przeciwnym przypadku wykonaj kod po słowie ELSE.*/ 
    var iWynik = 0; iWynik = Number(T)*Number(T); 
    document.getElementById('fkWynik').value = "Wynik działania wynosi: "+iWynik.toString(); 
  } else { document.getElementById('fkWynik').value = "Proszę wprowadzić liczbę!"; }  
    /* 
      "var T = "";" - Zadeklarowanie zmiennej tekstowej o nazwie "T". 
      "document.getElementById('fkEdit').value" - Pobranie danych wpisanych 
                                                  w kontrolce/komponencie 
                                                  o nazwie "fkEdit". 
      "T = document.getElementById('fkEdit').value;" - Przepisanie pobranych danych 
                                                       (z kontrolki/komponentu o nazwie "fkEdit") 
                                                       do zmiennej tekstowej o nazwie "T". 
      "var iWynik = 0;" - Zadeklarowanie zmiennej liczbowej o nazwie "iWynik". 
      "Number(T)" - Zamiana tekstu zawierającego tylko cyfry na liczbę 
                    (na której można wykonywać działania arytmetyczne). 
      "Number(T)*Number(T);" - Wykonanie mnożenia tej samej liczby, która została pobrana 
                               z kontrolki/komponentu o nazwie "fkEdit". 
      "iWynik = Number(T)*Number(T);" - Przypisanie do zmiennej liczbowej o nazwie "iWynik" 
                                        wyniku z mnożenia dwóch tych samych liczb. 
      "iWynik.toString();" - Zamiana liczby na ciąg znaków zawierających wynik z mnożenia 
                             (czyli ciąg znaków zawierający tylko cyfry). 
      "Wynik działania wynosi: "+iWynik.toString();" - łączenie ciągów znaków 
                                                       (czyli połączenie tekstu zawartego 
                                                       pomiędzy cudzysłowami z ciągiem znaków 
                                                       zawierających wynik z mnożenia tej samej liczby). 
      "document.getElementById('fkWynik').value = "Wynik działania wynosi: "+iWynik.toString();" - Przypisanie połączonych ciągów znaków do kontrolki/komponentu o nazwie "fkWynik". 
    */ 
} 