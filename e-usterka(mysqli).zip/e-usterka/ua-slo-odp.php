﻿<HTML><HEAD><META CHARSET="utf-8"> 
<META NAME="keywords" CONTENT="eUsterki, e-Usterki, Usterki, Naprawa, Komputery, Serwis, Monitory, Klawiatury" /> 
<META NAME="description" CONTENT="Naprawa zgłoszonych usterek oraz pomoc w obsłudze programów." /> 
<LINK REL="shortcut icon" HREF="graf/eusterka.ico" /> 
<LINK REL="stylesheet" TYPE="text/css" HREF="graf/style.css" /> 
<SCRIPT TYPE="text/javascript" SRC="js_zewn.js"></SCRIPT> 
<TITLE>eUsterki (c)by Jan T. Biernat</TITLE> 
</HEAD> 
<?php 
  include_once('libsesje.php'); 
  include_once('eusterka.php'); 
  session_start(); 
  $UzytkownikAdm = ""; 
  function FormatkaOknoDialogowe($F_Tytul = "", $F_Opis = "", $F_Komunikat = "", $F_KlawOpisz = "") { 
    //FormatkaOknoDialogowe. 
      $F_Komunikat = trim($F_Komunikat); 
      echo " 
             <TABLE CLASS=\"tabela-niewidoczna\" STYLE=\"width:750px;\" CELLPADDING=\"3px\"> 
                    <CAPTION STYLE=\"text-align:center;\"><FONT STYLE=\"font-size:13pt; font-weight:bold;\">".trim($F_Tytul)."</FONT></CAPTION> 
                    <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" COLSPAN=\"3\">&nbsp;</TD></TR> 
           "; 
      if($F_Komunikat != "") { 
        echo "\n      <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" COLSPAN=\"3\" STYLE=\"text-align:right; color:red;\">".$F_Komunikat."&nbsp;</TD></TR>"; 
      } 
      echo "\n 
                    <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:60px; font-size:13pt;\">Opis</TD> 
                        <TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:9px\">:</TD> 
                        <TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:800px;\"> 
                            <INPUT TYPE=\"text\" MAXLENGTH=\"120\" NAME=\"fkF_Opis\" VALUE=\"".trim($F_Opis)."\" STYLE=\"width:780px; font-size:14pt;\" AUTOFOCUS /> 
                        </TD> 
                    </TR> 
                    <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" COLSPAN=\"3\" STYLE=\"text-align:right;\"> 
                            <INPUT TYPE=\"submit\" VALUE=\"".trim($F_KlawOpisz)."\" NAME=\"fkKlawWykonaj\" />&nbsp;&nbsp; 
                            <INPUT TYPE=\"submit\" VALUE=\"Anuluj\" NAME=\"fkAnulujForm\" />&nbsp; 
                         </TD> 
                    </TR> 
             </TABLE> 
           "; 
    return $F_Opis; 
  } 
 ?> 
<BODY ONLOAD="DzisiajJest();"> 
      <DIV ID="strona"> 
           <DIV ID="naglowek"> 
                <DIV ID="naglowek-p1"><IMG SRC="graf/nag-eusterka.gif" /></DIV> 
                <DIV ID="naglowek-p2"> 
                     <TABLE BORDER="0" CLASS="naglowek-tabela"> 
                            <TR CLASS="naglowek-tabela-komorka"><TD STYLE="width:495px; text-align:right;">&nbsp;</TD></TR> 
                            <TR CLASS="naglowek-tabela-komorka"><TD ID="InfDzisiajJest" STYLE="width:495px; text-align:right;"></TD></TR> 
                     </TABLE> 
                </DIV> 
           </DIV> 
           <DIV ID="naglowek-linia-pozioma"><IMG STYLE="width:1024px;" SRC="graf/nag-linia-pozioma.gif" /></DIV> 
           <DIV ID="zawartosc"> 
                <DIV ID="zawartosc-g-p1"> 
                     <?php 
                           if((isset($_SESSION['login']) == true) 
                           && (isset($_SESSION['password']) == true)
                           && (!empty($_SESSION['login']))
                           && (!empty($_SESSION['password']))) { 
                             $UzytkownikAdm = bdWyswietlDaneUzytkownika($_SESSION['login'], $_SESSION['password']); 
                           } 
                      ?> 
                </DIV> 
                <DIV ID="zawartosc-g-p2"> 
                     <TABLE BORDER="0" STYLE="margin: 0px auto;" ALIGN="right"> 
                            <TR><TD ROWSPAN="2"><A HREF="ua-lu.php" TITLE="Lista zgłoszonych usterek"><IMG SRC="graf/menu-a-lu.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="ua-lua.php" TITLE="Archiwum zgłoszonych usterek"><IMG SRC="graf/menu-a-arch.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="ua-konta.php" TITLE="Lista użytkowników"><IMG SRC="graf/menu-a-uz.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="ua-slo-usterka.php" TITLE="Słowniki"><IMG SRC="graf/menu-a-slo.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="index0.php" TITLE="Wyloguj się"><IMG SRC="graf/menu-drzwi.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                            </TR> 
                     </TABLE><BR/> 
                </DIV> 
                <DIV ID="zawartosc-dolne"> 
                     <BR/><BR/> 
                     <CENTER> 
                     <FONT CLASS="tytul-strony">Słownik odpowiedzi</FONT><BR/><BR/><BR/> 
                     <FORM METHOD="post" ACTION=""> 
                           <?php 
                                 //Deklaracja zmiennych tekstowych. 
                                   $SQL_Polacz = ""; 
                                   $SQL_Query = ""; 
                                   $SQL_Info = ""; 
                                   $SQL_Usun = ""; 
                                   $SQL_Pokaz = ""; 
                                   $logCzyJest = 0; 
                                   $SQL_CzyJest = ""; 
                                   $Licznik = 0; 
                                 //Połączenie z bazą. 
                                   $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); 
                                   if(($SQL_Polacz) && (trim($UzytkownikAdm) != "")) { 
                                     @mysqli_set_charset($SQL_Polacz,"utf8"); 
                                     //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
                                     if(@mysqli_select_db($SQL_Polacz, "usterka")) { 
                                       //MySQL: Usuń wybrane rekordy (wiersze). 
                                         if((isset($_POST['fkUsunWiersz']) == true) 
                                         && (trim($_POST['fkUsunWiersz']) == "Usuń") 
                                         && (isset($_POST['fkRekord']) == true)) { 
                                           for($I= 0; $I < count($_POST['fkRekord']); $I++) { 
                                             $SQL_Usun = ""; $SQL_Usun = " 
                                                                           DELETE FROM `slo_odp` 
                                                                           WHERE `odp_id` = '".(htmlspecialchars(trim($_POST['fkRekord'][$I])))."' 
                                                                         "; 
                                             @mysqli_query($SQL_Polacz, $SQL_Usun); 
                                           } 
                                         } 
                                       //MySQL: Dodaj nowy opis odpowiedzi. 
                                         if((isset($_POST['fkKlawWykonaj']) == true) 
                                         && (trim($_POST['fkKlawWykonaj']) == "Dodaj opis") 
                                         && (trim($_POST['fkF_Opis']) != "")) { 
                                           $logCzyJest = 0; 
                                           $SQL_Query = ""; $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                                                                      SELECT DISTINCT `odp_opis` 
                                                                                                      FROM `slo_odp` 
                                                                                                      WHERE `odp_opis` = '".htmlspecialchars(trim($_POST['fkF_Opis']))."' 
                                                                                                    "); 
                                           if($SQL_Query) { 
                                             if(@mysqli_num_rows($SQL_Query) > 0) { $logCzyJest = 1; } 
                                           } 
                                           //Jeżeli brak opisu odpowiedzi, to wpisz do bazy. 
                                             if($logCzyJest == 0) { 
                                               @mysqli_query($SQL_Polacz, " 
                                                                            INSERT INTO `slo_odp` 
                                                                            SET `odp_id` = '".(date("YmdHis"))."', 
                                                                                `odp_opis` = '".htmlspecialchars(trim($_POST['fkF_Opis']))."' 
                                                                          "); 
                                             } 
                                         } 
                                       //Formularz: Dodaj nowy opis odpowiedzi. 
                                         if((isset($_POST['fkNowyOdp']) == true) 
                                         && (trim($_POST['fkNowyOdp']) == "Nowa odpowiedź")) { 
                                           echo "<CENTER>"; 
                                           FormatkaOknoDialogowe("Nowy opis odpowiedzi", "", "", "Dodaj opis"); 
                                           echo "</CENTER><BR/>"; 
                                         } 
                                       //MySQL: Aktualizuj opis odpowiedzi. 
                                         if((isset($_POST['fkKlawWykonaj']) == true) 
                                         && (trim($_POST['fkKlawWykonaj']) == "Aktualizuj opis") 
                                         && (trim($_POST['fkF_Opis']) != "")) { 
                                           $logCzyJest = 0; 
                                           $SQL_CzyJest = ""; $SQL_CzyJest = @mysqli_query($SQL_Polacz, " 
                                                                                                          SELECT DISTINCT `odp_opis` 
                                                                                                          FROM `slo_odp` 
                                                                                                          WHERE `odp_opis` = '".htmlspecialchars(trim($_POST['fkF_Opis']))."' 
                                                                                                        "); 
                                           if($SQL_CzyJest) { 
                                             if(@mysqli_num_rows($SQL_CzyJest) > 0) { $logCzyJest = 1; } 
                                           } 
                                           //Aktualizuj opis odpowiedzi. 
                                             if($logCzyJest == 0) { 
                                               @mysqli_query($SQL_Polacz, " 
                                                                            UPDATE `slo_odp` 
                                                                            SET `odp_opis` = '".htmlspecialchars(trim($_POST['fkF_Opis']))."' 
                                                                            WHERE `odp_id` = '".htmlspecialchars(trim($_POST['fkPoprawOpisA']))."' 
                                                                          "); 
                                             } 
                                         } 
                                       //Formularz: Popraw opis odpowiedzi. 
                                         if((isset($_POST['fkPoprawOpis']) == true) 
                                         && (trim($_POST['fkPoprawOpis']) != "")) { 
                                           $SQL_Pokaz = ""; 
                                           $SQL_Pokaz = " 
                                                          SELECT DISTINCT `odp_id`, 
                                                                          `odp_opis` 
                                                          FROM `slo_odp` 
                                                          WHERE `odp_id` = '".htmlspecialchars(trim($_POST['fkPoprawOpis']))."' 
                                                        "; 
                                           $SQL_Query = ""; 
                                           $SQL_Query = @mysqli_query($SQL_Polacz, $SQL_Pokaz); 
                                           if($SQL_Query) { 
                                             if(@mysqli_num_rows($SQL_Query) > 0) { 
                                               $SQL_Info = ""; 
                                               while($SQL_Info = @mysqli_fetch_array($SQL_Query)) { 
                                                 echo "<CENTER> 
                                                       <INPUT TYPE=\"hidden\" VALUE=\"".$_POST['fkPoprawOpis']."\" NAME=\"fkPoprawOpisA\" /> 
                                                      "; 
                                                 FormatkaOknoDialogowe("Popraw opis odpowiedzi", $SQL_Info[1], "", "Aktualizuj opis"); 
                                                 echo "</CENTER><BR/>"; 
                                               } 
                                             } 
                                           } 
                                         } 
                                       //Pobranie danych z bazy. 
                                         $SQL_Query = ""; 
                                         $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                                                   SELECT DISTINCT `odp_id`, 
                                                                                                   `odp_opis` 
                                                                                   FROM `slo_odp` 
                                                                                   ORDER BY `odp_opis` ASC 
                                                                                 "); 
                                         if($SQL_Query) { 
                                           if(@mysqli_num_rows($SQL_Query) > 0) { 
                                             //Nagłówki tabeli. 
                                               echo " 
                                                      <TABLE BORDER=\"0\" STYLE=\"width:934px;\" CELLPADDING=\"3px\"> 
                                                             <TR><TD STYLE=\"text-align:left;\"><A CLASS=\"link_menu0\" HREF=\"ua-slo-usterka.php\">Słownik usterek</A></TD> 
                                                                 <TD STYLE=\"text-align:right;\"> 
                                                                     <INPUT TYPE=\"submit\" NAME=\"fkNowyOdp\" TITLE=\"\" VALUE=\"Nowa odpowiedź\" /> 
                                                                 </TD> 
                                                             </TR> 
                                                      </TABLE> 
                                                      <TABLE CLASS=\"tabela0\" CELLPADDING=\"3px\"> 
                                                             <TR><TD CLASS=\"tabela0_nag1\" STYLE=\"width:35px;\">&nbsp;LP&nbsp;</TD> 
                                                                 <TD CLASS=\"tabela0_nag2\" STYLE=\"width:795px;\">&nbsp;Lista odpowiedzi&nbsp;</TD> 
                                                                 <TD CLASS=\"tabela0_nag2\"  STYLE=\"width:69px;\" COLSPAN=\"2\">&nbsp;Opcje&nbsp;</TD> 
                                                             </TR> 
                                                    "; 
                                               $SQL_Info = ""; 
                                               while($SQL_Info = @mysqli_fetch_array($SQL_Query)) { 
                                                 $Licznik++; 
                                                 //Pobierz dane z bazy i wyświetl je w tabeli. 
                                                   echo " 
                                                          <TR CLASS=\"tabela0_wiersz_zaznacz\">
                                                              <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:35px; text-align: right;\">&nbsp;".$Licznik."&nbsp;</TD> 
                                                              <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:795px;\" >".$SQL_Info[1]."&nbsp;</TD> 
                                                              <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:21px; text-align:center;\"> 
                                                                  <INPUT TYPE=\"submit\" BORDER=\"0\" NAME=\"fkPoprawOpis\" VALUE=\"".$SQL_Info[0]."\" TITLE=\"Popraw opis odpowiedzi\" CLASS=\"input_edycja\" /> 
                                                              </TD> 
                                                              <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:14px; text-align:center;\"> 
                                                                  <INPUT TYPE=\"checkbox\" VALUE=\"".$SQL_Info[0]."\" NAME=\"fkRekord[]\" TITLE=\"Zaznacz wiersz, jeśli ma być usunięty\"/> 
                                                              </TD> 
                                                          </TR> 
                                                        "; 
                                               } 
                                             //Przycisk pod tabelą. 
                                               echo " 
                                                          <TR STYLE=\"background-color:white;\"> 
                                                              <TD CLASS=\"tabela0_wiersz\" COLSPAN=\"4\" STYLE=\"text-align:right;\"> 
                                                                  <INPUT TYPE=\"submit\" NAME=\"fkUsunWiersz\" TITLE=\"Usuń zaznaczone wiersze\" VALUE=\"Usuń\" />&nbsp;&nbsp; 
                                                              </TD> 
                                                          </TR> 
                                                      </TABLE> 
                                                  "; 
                                         } else { echo SG_infBrakDanych; } 
                                       } 
                                     } 
                                     @mysqli_close($SQL_Polacz); 
                                   } else { echo SG_infBrakDanych; } 
                            ?> 
                     </FORM> 
                     </CENTER> 
                </DIV> 
           </DIV> 
           <DIV ID="stopka">eUsterki (c)by Jan T. Biernat</DIV> 
      </DIV> 
</BODY> 
</HTML> 