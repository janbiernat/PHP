﻿<?php 
  //Usuwanie sesji. 
    $_SESSION = array(); //Usunięcie wszystkich zmiennych występujących w sesji. 
    header("Location: index.php"); //Przejście do strony logowania. 
    exit(); //Zamknięcie strony. 
 ?> 