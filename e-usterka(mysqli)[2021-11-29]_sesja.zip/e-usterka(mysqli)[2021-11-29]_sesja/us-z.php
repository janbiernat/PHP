﻿<?php 
  include_once('eusterka.php'); 
  session_start(); 
  Sesja_AutoWylog("sesja_akt", "index.php"); 
  //Deklaracja zmiennych. 
    $UzytkownikZw = ""; 
    $SQL_Polacz = ""; 
    $SQL_Query = ""; 
    $UsterkaZgloszona = 0; 
  //Sprawdzenie sesji. 
    if((isset($_SESSION['login']) == true) 
    && (isset($_SESSION['password']) == true)) { 
      //Sprawdź czy formularz jest wypełniony. 
        if((isset($_POST['fkUsterkaDodaj']) == true) 
        &&(strtolower($_POST['fkUsterkaDodaj']) == "dodaj") 
        && (trim($_POST['fkNrSali']) != "") 
        && (trim($_POST['fkKtoZgl']) != "") 
        && (trim($_POST['fkOpisUsterki']) != "")
        && (trim($_SESSION['login']) != "")
        && (!empty($_SESSION['login'])) 
        && (!empty($_SESSION['password']))) { 
          $SQL_Polacz = @mysqli_connect(SG_SerwerPolaczHost, SG_SerwerPolaczUzyt, SG_SerwerPolaczHaslo); 
          if($SQL_Polacz) { 
            @mysqli_set_charset($SQL_Polacz,"utf8"); 
            //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
            if(@mysqli_select_db($SQL_Polacz, SG_BazaUsterka)) { 
              $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                        SELECT DISTINCT `zglos_nr_sali`, 
                                                                        `zglos_opis`, 
                                                                        `zglos_naprawiony` 
                                                        FROM `zglos` 
                                                        WHERE `zglos_nr_sali` = '".ZnakiSprawdz($SQL_Polacz, $_POST['fkNrSali'])."' 
                                                        AND `zglos_opis` = '".ZnakiSprawdz($SQL_Polacz, $_POST['fkOpisUsterki'])."' 
                                                        AND `zglos_naprawiony` = '0' 
                                                      "); 
              if($SQL_Query) { 
                if(@mysqli_num_rows($SQL_Query) > 0) { $UsterkaZgloszona = 1; } 
              } 
              //Jeżeli brak zgłoszonej usterki, to wpisz do bazy. 
                if($UsterkaZgloszona == 0) { 
                  @mysqli_query($SQL_Polacz, " 
                                               INSERT INTO `zglos` 
                                               SET `zglos_id` = '".(date("YmdHis"))."', 
                                                   `zglos_nr_sali` = '".substr(SalaNrSpr(ZnakiSprawdz($SQL_Polacz, $_POST['fkNrSali'])), 0, 3)."', 
                                                   `zglos_kto` = '".ucwords(ZnakiSprawdz($SQL_Polacz, $_POST['fkKtoZgl']))."', 
                                                   `zglos_opis` = '".ZnakiSprawdz($SQL_Polacz, $_POST['fkOpisUsterki'])."', 
                                                   `zglos_data_zgl` = '".(date("Y-m-d"))."', 
                                                   `zglos_naprawiony` = '0', 
                                                   `zglos_nr_komp` = '".(int)ZnakiSprawdz($SQL_Polacz, $_POST['fkNrKomp'])."' 
                                             "); 
                } 
            } 
            @mysqli_close($SQL_Polacz); 
          } 
        } 
    } 
 ?> 
<BODY ONLOAD="DzisiajJest();"> 
      <DIV ID="strona"> 
           <DIV ID="naglowek"> 
                <DIV ID="naglowek-p1"><IMG SRC="graf/nag-eusterka.gif" /></DIV> 
                <DIV ID="naglowek-p2"> 
                     <TABLE BORDER="0" CLASS="naglowek-tabela"> 
                            <TR CLASS="naglowek-tabela-komorka"><TD STYLE="width:495px; text-align:right;">&nbsp;</TD></TR> 
                            <TR CLASS="naglowek-tabela-komorka"><TD ID="InfDzisiajJest" STYLE="width:495px; text-align:right;"></TD></TR> 
                     </TABLE> 
                </DIV> 
           </DIV> 
           <DIV ID="naglowek-linia-pozioma"><IMG STYLE="width:1024px;" SRC="graf/nag-linia-pozioma.gif" /></DIV> 
           <DIV ID="zawartosc"> 
                <DIV ID="zawartosc-g-p1"> 
                     <?php 
                           if((isset($_SESSION['login']) == true) 
                           && (isset($_SESSION['password']) == true)) { 
                             $UzytkownikZw = bdWyswietlDaneUzytkownika($_SESSION['login'], $_SESSION['password']); 
                           } 
                      ?> 
                </DIV> 
                <DIV ID="zawartosc-g-p2"> 
                     <TABLE BORDER="0" STYLE="margin: 0px auto;" ALIGN="right"> 
                            <TR><TD ROWSPAN="2"><A HREF="us-z.php" TITLE="Zgłoś usterkę"><IMG SRC="graf/menu-us-1.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="us-l.php" TITLE="Lista zgłoszonych usterek"><IMG SRC="graf/menu-us-2.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="index0.php" TITLE="Wyloguj się"><IMG SRC="graf/menu-drzwi.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                            </TR> 
                     </TABLE><BR/> 
                </DIV> 
                <DIV ID="zawartosc-dolne"> 
                     <CENTER> 
                     <BR/><BR/> 
                     <FONT CLASS="tytul-strony">Zgłoś usterkę</FONT><BR/><BR/> 
                     <FORM METHOD="post" ACTION=""> 
                           <TABLE BORDER="0"> 
                                  <TR><TD>Imię i nazwisko</TD> 
                                      <TD>&nbsp;:&nbsp;</TD> 
                                      <TD><INPUT TYPE="text" CLASS="usterka_zgl" NAME="fkKtoZgl" ID="KtoZgl" PLACEHOLDER="" MAXLENGTH="90" SIZE="90" VALUE="<?php echo $UzytkownikZw; ?>" STYLE="width:499px; text-transform:capitalize;" READONLY /></TD> 
                                  </TR> 
                                  <TR><TD>Nr sali</TD> 
                                      <TD>&nbsp;:&nbsp;</TD> 
                                      <TD><INPUT TYPE="number" CLASS="usterka_zgl" NAME="fkNrSali" ID="NrSali" PLACEHOLDER="" MAXLENGTH="3" SIZE="3" VALUE="" STYLE="width:77px;" AUTOFOCUS /></TD> 
                                  </TR> 
                                  <TR><TD>Komputer nr</TD> 
                                      <TD>&nbsp;:&nbsp;</TD> 
                                      <TD><SELECT CLASS="usterka_zgl" NAME="fkNrKomp" ID="NrKomp" PLACEHOLDER="" MAXLENGTH="3" SIZE="0" VALUE="" STYLE="width:77px;" /> 
                                                  <?php 
                                                        for($I = 0; $I < 50; $I++) { 
                                                          echo "<OPTION VALUE=\""; 
                                                          if($I < 10) { echo "0$I\">0"; } 
                                                          else { echo "$I\">"; } 
                                                          echo "$I</OPTION>"; 
                                                        } 
                                                   ?> 
                                          </SELECT> 
                                      </TD> 
                                  </TR> 
                                  <TR><TD>Opis usterki</TD> 
                                      <TD>&nbsp;:&nbsp;</TD> 
                                      <TD><INPUT TYPE="text" CLASS="usterka_zgl" NAME="fkOpisUsterki" ID="OpisUsterki" LIST="SloUsterki" PLACEHOLDER="" MAXLENGTH="188" SIZE="33" VALUE="" STYLE="width:699px;" /> 
                                                 <DATALIST ID="SloUsterki"> 
                                                           <?php 
                                                                 bdPobierzDaneSLO('slo_usterka', 'usterka_opis'); 
                                                            ?> 
                                                 </DATALIST> 
                                      </TD> 
                                  </TR> 
                                  <TR><TD COLSPAN="3" STYLE="text-align:right;"> 
                                          <FONT CLASS="tekst13-blad"> 
                                                <?php 
                                                      if($UsterkaZgloszona == 1) { echo "Taka usterka została już zgłoszona!"; } 
                                                 ?> 
                                          </FONT> 
                                      </TD> 
                                  </TR> 
                                  <TR><TD COLSPAN="3">&nbsp;</TD></TR> 
                                  <TR><TD COLSPAN="3" ALIGN="right"> 
                                          <INPUT TYPE="submit" NAME="fkUsterkaDodaj" ID="UsterkaDodaj" onClick="" VALUE="Dodaj" TITLE="Dodaj zgłoszenie o usterce." />&nbsp;&nbsp; 
                                          <INPUT TYPE="reset" VALUE="Wyczyść" />&nbsp; 
                                      </TD> 
                                  </TR> 
                           </TABLE> 
                     </FORM><BR/> 
                     </CENTER> 
                </DIV> 
           </DIV> 
           <DIV ID="stopka">eUsterki (c)by Jan T. Biernat</DIV> 
      </DIV> 
</BODY> 
</HTML> 