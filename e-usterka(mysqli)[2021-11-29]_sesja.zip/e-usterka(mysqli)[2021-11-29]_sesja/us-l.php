﻿<?php 
  include_once('eusterka.php'); 
  session_start(); 
  $UzytkownikZw = ""; 
  Sesja_AutoWylog("sesja_akt", "index.php"); 
 ?> 
<BODY ONLOAD="DzisiajJest();"> 
      <DIV ID="strona"> 
           <DIV ID="naglowek"> 
                <DIV ID="naglowek-p1"><IMG SRC="graf/nag-eusterka.gif" /></DIV> 
                <DIV ID="naglowek-p2"> 
                     <TABLE BORDER="0" CLASS="naglowek-tabela"> 
                            <TR CLASS="naglowek-tabela-komorka"><TD STYLE="width:495px; text-align:right;">&nbsp;</TD></TR> 
                            <TR CLASS="naglowek-tabela-komorka"><TD ID="InfDzisiajJest" STYLE="width:495px; text-align:right;"></TD></TR> 
                     </TABLE> 
                </DIV> 
           </DIV> 
           <DIV ID="naglowek-linia-pozioma"><IMG STYLE="width:1024px;" SRC="graf/nag-linia-pozioma.gif" /></DIV> 
           <DIV ID="zawartosc"> 
                <DIV ID="zawartosc-g-p1"> 
                     <?php 
                           if((isset($_SESSION['login']) == true) 
                           && (isset($_SESSION['password']) == true)) { 
                             if((!empty($_SESSION['login'])) 
                             && (!empty($_SESSION['password']))) { 
                               $UzytkownikZw = bdWyswietlDaneUzytkownika($_SESSION['login'], $_SESSION['password']); 
                             } 
                           } 
                      ?> 
                </DIV> 
                <DIV ID="zawartosc-g-p2"> 
                     <TABLE BORDER="0" STYLE="margin: 0px auto;" ALIGN="right"> 
                            <TR><TD ROWSPAN="2"><A HREF="us-z.php" TITLE="Zgłoś usterkę"><IMG SRC="graf/menu-us-1.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="us-l.php" TITLE="Lista zgłoszonych usterek"><IMG SRC="graf/menu-us-2.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="index0.php" TITLE="Wyloguj się"><IMG SRC="graf/menu-drzwi.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                            </TR> 
                     </TABLE><BR/> 
                </DIV> 
                <DIV ID="zawartosc-dolne"> 
                     <CENTER> 
                     <BR/><BR/> 
                     <FONT CLASS="tytul-strony">Lista zgłoszonych usterek</FONT><BR/><BR/><BR/> 
                     <FORM METHOD="post" ACTION=""> 
                           <?php 
                                 //Deklaracja zmiennych tekstowych. 
                                   $SQL_Polacz = ""; 
                                   $SQL_Query = ""; 
                                   $SQL_Info = ""; 
                                   $SQL_Usun = ""; 
                                   $Licznik = 0; 
                                   $SQL_DaneSa = 0; 
                                 //Połączenie z bazą. 
                                   $SQL_Polacz = @mysqli_connect(SG_SerwerPolaczHost, SG_SerwerPolaczUzyt, SG_SerwerPolaczHaslo); 
                                   if($SQL_Polacz) { 
                                     @mysqli_set_charset($SQL_Polacz,"utf8"); 
                                     //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
                                     if(@mysqli_select_db($SQL_Polacz, SG_BazaUsterka)) { 
                                       //Usuń wybrany rekord. 
                                         if((isset($_POST['fkWycofaj']) == true) 
                                         && (strtolower($_POST['fkWycofaj']) == "wycofaj") 
                                         && (isset($_POST['fkRekord']) == true) 
                                         && (trim($UzytkownikZw) != "")) { 
                                           for($I= 0; $I < count($_POST['fkRekord']); $I++) { 
                                             $SQL_Usun = ""; 
                                             $SQL_Usun = " 
                                                           DELETE FROM `zglos` 
                                                           WHERE `zglos_id` = '".(ZnakiSprawdz($SQL_Polacz, $_POST['fkRekord'][$I]))."' 
                                                           AND `zglos_naprawiony` = '0' 
                                                         "; 
                                             @mysqli_query($SQL_Polacz, $SQL_Usun); 
                                           } 
                                         } 
                                       //Pobranie danych z bazy. 
                                       $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                                                 SELECT DISTINCT `zglos_id`, 
                                                                                                 `zglos_nr_sali`, 
                                                                                                 `zglos_opis`, 
                                                                                                 `zglos_kto`, 
                                                                                                 `zglos_odp`, 
                                                                                                 `zglos_naprawiony`, 
                                                                                                 `zglos_nr_komp` 
                                                                                 FROM `zglos` 
                                                                                 WHERE LOWER(`zglos_kto`) = LOWER('".ZnakiSprawdz($SQL_Polacz, $UzytkownikZw)."') 
                                                                                 AND `zglos_naprawiony` = '0' 
                                                                               "); 
                                       if($SQL_Query) { 
                                         if(@mysqli_num_rows($SQL_Query) > 0) { 
                                           $SQL_DaneSa = 1; 
                                           //Nagłówki tabeli. 
                                             echo " 
                                                    <TABLE CLASS=\"tabela0\" CELLPADDING=\"3px\"> 
                                                           <TR><TD CLASS=\"tabela0_nag1\" STYLE=\"width:25px;\">&nbsp;LP&nbsp;</TD> 
                                                               <TD CLASS=\"tabela0_nag2\" STYLE=\"width:740px;\">&nbsp;Lista zgłoszonych usterek&nbsp;</TD> 
                                                               <TD CLASS=\"tabela0_nag2\" STYLE=\"width:69px;\">&nbsp;Nr sali&nbsp;</TD> 
                                                               <TD CLASS=\"tabela0_nag2\"  STYLE=\"width:85px;\">&nbsp;Zaznacz&nbsp;</TD> 
                                                           </TR> 
                                                  "; 
                                           while($SQL_Info = @mysqli_fetch_array($SQL_Query)) { 
                                             $Licznik++; 
                                             //Pobierz dane z bazy i wyświetl je w tabeli. 
                                               echo " 
                                                      <TR CLASS=\"tabela0_wiersz_zaznacz\"> 
                                                          <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:25px; text-align: right;\">&nbsp;".$Licznik."&nbsp;</TD> 
                                                          <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:740px;\">Komp. nr:&nbsp;".$SQL_Info[6].",&nbsp;".$SQL_Info[2]."&nbsp; 
                                                              <BR/><FONT CLASS=\"tabela-info\">Odp.: ".ZnakPytaj($SQL_Info[4])."</FONT>&nbsp; 
                                                          </TD> 
                                                          <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:69px; text-align:right;\" >&nbsp;".$SQL_Info[1]."&nbsp;</TD> 
                                                          <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:85px; text-align:center;\"> 
                                                              <INPUT TYPE=\"checkbox\" VALUE=\"".$SQL_Info[0]."\" NAME=\"fkRekord[]\" TITLE=\"Zaznacz wiersz, jeżeli zgłoszona usterka ma być wycofana (tj. nieaktualna)\" /> 
                                                          </TD> 
                                                      </TR> 
                                                    "; 
                                           } 
                                           //Przycisk pod tabelą. 
                                             echo " 
                                                    <TR STYLE=\"background-color:white;\"> 
                                                        <TD CLASS=\"tabela0_wiersz\" COLSPAN=\"4\" STYLE=\"text-align:right;\"> 
                                                            <INPUT TYPE=\"submit\" NAME=\"fkWycofaj\" TITLE=\"Wycofaj zaznaczone usterki.\" VALUE=\"Wycofaj\" />&nbsp;&nbsp; 
                                                        </TD> 
                                                    </TR> 
                                                    </TABLE> 
                                                  "; 
                                         } 
                                       } 
                                     } 
                                     @mysqli_close($SQL_Polacz); 
                                   } 
                                   //Jeżeli zgłoszonych usterek nie ma, to wyświetl stosowny komunikat. 
                                     if($SQL_DaneSa == 0) { echo SG_infBrakDanych; } 
                            ?> 
                     </FORM> 
                     </CENTER> 
                     <BR/><BR/> 
                </DIV> 
           </DIV> 
           <DIV ID="stopka">eUsterki (c)by Jan T. Biernat</DIV> 
      </DIV> 
</BODY> 
</HTML> 