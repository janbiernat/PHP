﻿<?php 
  include_once('eusterka.php'); 
  session_start(); 
  $UzytkownikAdm = ""; 
  Sesja_AutoWylog("sesja_akt", "index.php"); 
 ?> 
<BODY ONLOAD="DzisiajJest();"> 
      <DIV ID="strona"> 
           <DIV ID="naglowek"> 
                <DIV ID="naglowek-p1"><IMG SRC="graf/nag-eusterka.gif" /></DIV> 
                <DIV ID="naglowek-p2"> 
                     <TABLE BORDER="0" CLASS="naglowek-tabela"> 
                            <TR CLASS="naglowek-tabela-komorka"><TD STYLE="width:495px; text-align:right;">&nbsp;</TD></TR> 
                            <TR CLASS="naglowek-tabela-komorka"><TD ID="InfDzisiajJest" STYLE="width:495px; text-align:right;"></TD></TR> 
                     </TABLE> 
                </DIV> 
           </DIV> 
           <DIV ID="naglowek-linia-pozioma"><IMG STYLE="width:1024px;" SRC="graf/nag-linia-pozioma.gif" /></DIV> 
           <DIV ID="zawartosc"> 
                <DIV ID="zawartosc-g-p1"> 
                     <?php 
                           if((isset($_SESSION['login']) == true) 
                           && (isset($_SESSION['password']) == true)
                           && (!empty($_SESSION['login']))
                           && (!empty($_SESSION['password']))) { 
                             $UzytkownikAdm = bdWyswietlDaneUzytkownika($_SESSION['login'], $_SESSION['password']); 
                           } 
                      ?> 
                </DIV> 
                <DIV ID="zawartosc-g-p2"> 
                     <TABLE BORDER="0" STYLE="margin: 0px auto;" ALIGN="right"> 
                            <TR><TD ROWSPAN="2"><A HREF="ua-lu.php" TITLE="Lista zgłoszonych usterek"><IMG SRC="graf/menu-a-lu.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="ua-lua.php" TITLE="Archiwum zgłoszonych usterek"><IMG SRC="graf/menu-a-arch.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="ua-konta.php" TITLE="Lista użytkowników"><IMG SRC="graf/menu-a-uz.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="ua-slo-usterka.php" TITLE="Słowniki"><IMG SRC="graf/menu-a-slo.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="index0.php" TITLE="Wyloguj się"><IMG SRC="graf/menu-drzwi.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                            </TR> 
                     </TABLE><BR/> 
                </DIV> 
                <DIV ID="zawartosc-dolne"> 
                     <BR/><BR/> 
                     <CENTER> 
                     <FORM METHOD="post" ACTION=""> 
                           <?php 
                                 //Deklaracja zmiennych tekstowych. 
                                   $SQL_Polacz = ""; 
                                   $SQL_Query = ""; 
                                   $SQL_Info = ""; 
                                   $SQL_Usun = ""; 
                                   $Licznik = 0; 
                                 //Połączenie z bazą. 
                                   $SQL_Polacz = @mysqli_connect(SG_SerwerPolaczHost, SG_SerwerPolaczUzyt, SG_SerwerPolaczHaslo); 
                                   if(($SQL_Polacz) && (trim($UzytkownikAdm) != "")) { 
                                     @mysqli_set_charset($SQL_Polacz,"utf8"); 
                                     //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
                                     if(@mysqli_select_db($SQL_Polacz, SG_BazaUsterka)) { 
                                       //Oznacz wybrany rekord jako naprawiony. 
                                         if((isset($_POST['fkUsunWiersz']) == true) 
                                         && (trim($_POST['fkUsunWiersz']) == "Usuń") 
                                         && (isset($_POST['fkRekord']) == true)) { 
                                           for($I= 0; $I < count($_POST['fkRekord']); $I++) { 
                                             $SQL_Usun = ""; $SQL_Usun = " 
                                                                           DELETE FROM `zglos` 
                                                                           WHERE `zglos_id` = '".(ZnakiSprawdz($SQL_Polacz, $_POST['fkRekord'][$I]))."' 
                                                                         "; 
                                             @mysqli_query($SQL_Polacz, $SQL_Usun); 
                                           } 
                                         } 
                                       //Pobranie danych z bazy. 
                                       $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                                                 SELECT DISTINCT `zglos_id`, 
                                                                                                 `zglos_nr_sali`, 
                                                                                                 `zglos_opis`, 
                                                                                                 `zglos_kto`, 
                                                                                                 `zglos_odp`, 
                                                                                                 `zglos_data_zgl`, 
                                                                                                 `zglos_data_wyk_napr`, 
                                                                                                 `zglos_naprawiony`, 
                                                                                                 `zglos_nr_komp` 
                                                                                 FROM `zglos` 
                                                                                 WHERE `zglos_naprawiony` = '1' 
                                                                                 ORDER BY `zglos_data_zgl` DESC 
                                                                               "); 
                                       if($SQL_Query) { 
                                         if(@mysqli_num_rows($SQL_Query) > 0) { 
                                           //Nagłówki tabeli. 
                                             echo " 
                                                    <FONT CLASS=\"tytul-strony\">Archiwum usterek naprawionych</FONT><BR/><BR/><BR/> 
                                                    <TABLE CLASS=\"tabela0\" CELLPADDING=\"3px\"> 
                                                           <TR><TD CLASS=\"tabela0_nag1\" STYLE=\"width:35px;\">&nbsp;LP&nbsp;</TD> 
                                                               <TD CLASS=\"tabela0_nag2\" STYLE=\"width:802px;\">&nbsp;Lista naprawionych usterek&nbsp;</TD> 
                                                               <TD CLASS=\"tabela0_nag2\" STYLE=\"width:69px;\">&nbsp;Nr sali&nbsp;</TD> 
                                                               <TD CLASS=\"tabela0_nag2\"  STYLE=\"width:30px;\">&nbsp;Zaznacz&nbsp;</TD> 
                                                           </TR> 
                                                  "; 
                                           while($SQL_Info = @mysqli_fetch_array($SQL_Query)) { 
                                             $Licznik++; 
                                             //Pobierz dane z bazy i wyświetl je w tabeli. 
                                               echo " 
                                                      <TR CLASS=\"tabela0_wiersz_zaznacz\">
                                                          <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:35px; text-align: right;\">&nbsp;".$Licznik."&nbsp;</TD> 
                                                          <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:802px;\">Komp. nr:&nbsp;".$SQL_Info[8].",&nbsp;".$SQL_Info[2]." 
                                                              <FONT CLASS=\"tabela-info\"> 
                                                                    <BR/>Kto zgłosił: ".$SQL_Info[3]." 
                                                                    <BR/>Odp.: ".$SQL_Info[4]." 
                                                                    <BR/>Data zgłoszenia: ".$SQL_Info[5].",&nbsp;&nbsp; 
                                                                         &nbsp;Data naprawy: ".$SQL_Info[6]." 
                                                              </FONT> 
                                                          </TD> 
                                                          <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:69px; text-align:right;\">".$SQL_Info[1]."&nbsp;</TD> 
                                                          <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:28px; text-align:center;\"> 
                                                              <INPUT TYPE=\"checkbox\" VALUE=\"".$SQL_Info[0]."\" NAME=\"fkRekord[]\" TITLE=\"Zaznacz wiersz, jeśli ma być usunięty\" /> 
                                                          </TD> 
                                                      </TR> 
                                                    "; 
                                           } 
                                           //Przycisk pod tabelą. 
                                             echo " 
                                                    <TR STYLE=\"background-color:white;\"> 
                                                        <TD CLASS=\"tabela0_wiersz\" COLSPAN=\"4\" STYLE=\"text-align:right;\"> 
                                                            <INPUT TYPE=\"submit\" NAME=\"fkUsunWiersz\" TITLE=\"Usuń oznaczone wiersze\" VALUE=\"Usuń\" />&nbsp;&nbsp; 
                                                        </TD> 
                                                    </TR> 
                                                    </TABLE> 
                                                  "; 
                                         } else { echo SG_infBrakDanych; } 
                                       } 
                                     } 
                                     @mysqli_close($SQL_Polacz); 
                                   } else { echo SG_infBrakDanych; } 
                            ?> 
                     </FORM> 
                     </CENTER> 
                </DIV> 
           </DIV> 
           <DIV ID="stopka">eUsterki (c)by Jan T. Biernat</DIV> 
      </DIV> 
</BODY> 
</HTML> 