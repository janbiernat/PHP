﻿<?php 
  //Usuwanie sesji. 
    $_SESSION = array();           //1. 
    @session_destroy();            //2. 
    header("Location: index.php"); //3. 
/* 
  Legenda: 
  1) Usunięcie wszystkich zmiennych występujących w sesji. 
     Tymczasowe zmienne są przechowywane w globalnej tablicy $_SESSION. 
  2) Zniszcz sesję. 
  3) Przejście do strony logowania. 
 */ 
 ?> 