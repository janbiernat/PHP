﻿<?php 
  include_once('eusterka.php'); 
  session_start(); 
  $UzytkownikAdm = ""; 
  Sesja_AutoWylog("sesja_akt", "index.php"); 
 ?> 
<BODY ONLOAD="DzisiajJest();"> 
      <DIV ID="strona"> 
           <DIV ID="naglowek"> 
                <DIV ID="naglowek-p1"><IMG SRC="graf/nag-eusterka.gif" /></DIV> 
                <DIV ID="naglowek-p2"> 
                     <TABLE BORDER="0" CLASS="naglowek-tabela"> 
                            <TR CLASS="naglowek-tabela-komorka"><TD STYLE="width:495px; text-align:right;">&nbsp;</TD></TR> 
                            <TR CLASS="naglowek-tabela-komorka"><TD ID="InfDzisiajJest" STYLE="width:495px; text-align:right;"></TD></TR> 
                     </TABLE> 
                </DIV> 
           </DIV> 
           <DIV ID="naglowek-linia-pozioma"><IMG STYLE="width:1024px;" SRC="graf/nag-linia-pozioma.gif" /></DIV> 
           <DIV ID="zawartosc"> 
                <DIV ID="zawartosc-g-p1"> 
                     <?php 
                           if((isset($_SESSION['login']) == true) 
                           && (isset($_SESSION['password']) == true)
                           && (!empty($_SESSION['login']))
                           && (!empty($_SESSION['password']))) { 
                             $UzytkownikAdm = bdWyswietlDaneUzytkownika($_SESSION['login'], $_SESSION['password']); 
                           } 
                      ?> 
                </DIV> 
                <DIV ID="zawartosc-g-p2"> 
                     <TABLE BORDER="0" STYLE="margin: 0px auto;" ALIGN="right"> 
                            <TR><TD ROWSPAN="2"><A HREF="ua-lu.php" TITLE="Lista zgłoszonych usterek"><IMG SRC="graf/menu-a-lu.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="ua-lua.php" TITLE="Archiwum zgłoszonych usterek"><IMG SRC="graf/menu-a-arch.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="ua-konta.php" TITLE="Lista użytkowników"><IMG SRC="graf/menu-a-uz.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="ua-slo-usterka.php" TITLE="Słowniki"><IMG SRC="graf/menu-a-slo.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2"><A HREF="index0.php" TITLE="Wyloguj się"><IMG SRC="graf/menu-drzwi.gif" CLASS="menu-rys" /></A></TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                                <TD ROWSPAN="2">&nbsp;</TD> 
                            </TR> 
                     </TABLE><BR/> 
                </DIV> 
                <DIV ID="zawartosc-dolne"> 
                     <BR/><BR/> 
                     <CENTER> 
                     <FONT CLASS="tytul-strony">Lista zgłoszonych usterek</FONT><BR/><BR/><BR/> 
                     <FORM METHOD="post" ACTION=""> 
                           <?php 
                                 //Deklaracja zmiennych tekstowych. 
                                   $SQL_Polacz = ""; 
                                   $SQL_Query = ""; 
                                   $SQL_Info = ""; 
                                   $SQL_Usun = ""; 
                                   $SQL_Pokaz = ""; 
                                   $SQL_Aktualizuj = ""; 
                                   $Licznik = 0; 
                                 //Połączenie z bazą. 
                                   $SQL_Polacz = @mysqli_connect(SG_SerwerPolaczHost, SG_SerwerPolaczUzyt, SG_SerwerPolaczHaslo); 
                                   if(($SQL_Polacz) && (trim($UzytkownikAdm) != "")) { 
                                     @mysqli_set_charset($SQL_Polacz,"utf8"); 
                                     //echo "<BR/>Kodowanie polskich znaków ustawione jest na: ".$SQL_Polacz -> character_set_name(); 
                                     if(@mysqli_select_db($SQL_Polacz, SG_BazaUsterka)) { 
                                       //Oznacz wybrany rekord jako naprawiony. 
                                         if((isset($_POST['fkNaprawione']) == true) 
                                         && (strtolower($_POST['fkNaprawione']) == "naprawione") 
                                         && (isset($_POST['fkRekord']) == true)) { 
                                           for($I= 0; $I < count($_POST['fkRekord']); $I++) { 
                                             $SQL_Usun = ""; 
                                             $SQL_Usun = " 
                                                           UPDATE `zglos` 
                                                           SET `zglos_data_wyk_napr` = '".(date("Y-m-d"))."', 
                                                               `zglos_naprawiony` = '1' 
                                                           WHERE `zglos_id` = '".(ZnakiSprawdz($SQL_Polacz, $_POST['fkRekord'][$I]))."' 
                                                         "; 
                                             @mysqli_query($SQL_Polacz, $SQL_Usun); 
                                           } 
                                         } 
                                       //Wprowadź odpowiedź do bazy. 
                                         if((isset($_POST['fkOdpOdpisz']) == true) 
                                         && (trim(strtolower($_POST['fkOdpOdpisz'])) == "odpisz") 
                                         && (trim($_POST['fkEdycjaOdpowiedz']) != "")) { 
                                           $SQL_Aktualizuj = ""; 
                                           $SQL_Aktualizuj = " 
                                                               UPDATE `zglos` 
                                                               SET `zglos_odp` = '".ZnakiSprawdz($SQL_Polacz, $_POST['fkEdycjaOdpowiedz'])."' 
                                                               WHERE `zglos_id` = '".ZnakiSprawdz($SQL_Polacz, $_POST['fkOdpOdpiszO'])."' 
                                                             "; 
                                           @mysqli_query($SQL_Polacz, $SQL_Aktualizuj);
                                         } 
                                       //Formularz: Odpowiedz na zgłoszoną usterkę. 
                                         if((isset($_POST['fkOdpNapisz']) == true) 
                                         && (trim($_POST['fkOdpNapisz']) != "")) { 
                                           $SQL_Pokaz = ""; 
                                           $SQL_Pokaz = " 
                                                          SELECT DISTINCT `zglos_id`, 
                                                                          `zglos_odp`, 
                                                                          `zglos_nr_sali`, 
                                                                          `zglos_opis`, 
                                                                          `zglos_nr_komp` 
                                                          FROM `zglos` 
                                                          WHERE `zglos_id` = '".ZnakiSprawdz($SQL_Polacz, $_POST['fkOdpNapisz'])."' 
                                                        "; 
                                           $SQL_Query = ""; 
                                           $SQL_Query = @mysqli_query($SQL_Polacz, $SQL_Pokaz); 
                                           if($SQL_Query) { 
                                             if(@mysqli_num_rows($SQL_Query) > 0) { 
                                               $SQL_Info = ""; 
                                               while($SQL_Info = @mysqli_fetch_array($SQL_Query)) { 
                                                 echo " 
                                                        <CENTER> 
                                                        <INPUT TYPE=\"hidden\" VALUE=\"".$_POST['fkOdpNapisz']."\" NAME=\"fkOdpOdpiszO\" /> 
                                                        <TABLE CLASS=\"tabela-niewidoczna\" STYLE=\"width:900px;\" CELLPADDING=\"3px\"> 
                                                               <CAPTION STYLE=\"text-align:center;\"><FONT STYLE=\"font-weight:bold; font-size:18pt;\">Odpowiedź na zgłoszoną usterkę</FONT></CAPTION> 
                                                               <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" COLSPAN=\"3\">&nbsp;</TD></TR> 
                                                               <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:120px; font-size:13pt;\">Sala nr</TD> 
                                                                   <TD CLASS=\"tabela-niewidoczna-wiersz\">:</TD> 
                                                                   <TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:750px; font-size:13pt;\">$SQL_Info[2]</TD> 
                                                               </TR> 
                                                               <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:120px; font-size:13pt;\">Komputer nr</TD> 
                                                                   <TD CLASS=\"tabela-niewidoczna-wiersz\">:</TD> 
                                                                   <TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:750px; font-size:13pt;\">$SQL_Info[4]</TD> 
                                                               </TR> 
                                                               <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:120px; font-size:13pt;\">Opis usterki</TD> 
                                                                   <TD CLASS=\"tabela-niewidoczna-wiersz\">:</TD> 
                                                                   <TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:750px; font-size:13pt;\">$SQL_Info[3]</TD> 
                                                               </TR> 
                                                               </TR> 
                                                               <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:120px; font-size:13pt;\">Wpisz odp.</TD> 
                                                                   <TD CLASS=\"tabela-niewidoczna-wiersz\">:</TD> 
                                                                   <TD CLASS=\"tabela-niewidoczna-wiersz\" STYLE=\"width:750px;\"> 
                                                                       <INPUT TYPE=\"text\" MAXLENGTH=\"120\" SIZE=\"109\" NAME=\"fkEdycjaOdpowiedz\" LIST=\"SloOdp\" VALUE=\"".$SQL_Info[1]."\" CLASS=\"usterka_odp\" STYLE=\"width:750px;\" AUTOFOCUS /></TD> 
                                                                              <DATALIST ID=\"SloOdp\">"; 
                                                                              bdPobierzDaneSLO('slo_odp', 'odp_opis'); 
                                                                             echo "</DATALIST> 
                                                               </TR> 
                                                               <TR><TD CLASS=\"tabela-niewidoczna-wiersz\" COLSPAN=\"3\" STYLE=\"text-align:right;\"> 
                                                                       <INPUT TYPE=\"submit\" VALUE=\"Odpisz\" NAME=\"fkOdpOdpisz\" /> 
                                                                       &nbsp;&nbsp;<INPUT TYPE=\"submit\" VALUE=\"Anuluj\" NAME=\"fkOdpAnuluj\" /></TD> 
                                                               </TR> 
                                                        </TABLE> 
                                                        </CENTER> 
                                                        <BR/> 
                                                      "; 
                                               } 
                                             } 
                                           } 
                                         } 
                                       //Pobranie danych z bazy. 
                                         $SQL_Query = ""; 
                                         $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                                                   SELECT DISTINCT `zglos_id`, 
                                                                                                   `zglos_nr_sali`, 
                                                                                                   `zglos_opis`, 
                                                                                                   `zglos_kto`, 
                                                                                                   `zglos_odp`, 
                                                                                                   `zglos_data_zgl`, 
                                                                                                   `zglos_data_wyk_napr`, 
                                                                                                   `zglos_naprawiony`, 
                                                                                                   `zglos_nr_komp` 
                                                                                   FROM `zglos` 
                                                                                   WHERE `zglos_naprawiony` = '0' 
                                                                                   ORDER BY `zglos_data_zgl` DESC 
                                                                                 "); 
                                         if($SQL_Query) { 
                                           if(@mysqli_num_rows($SQL_Query) > 0) { 
                                             //Nagłówki tabeli. 
                                               echo " 
                                                      <TABLE CLASS=\"tabela0\" CELLPADDING=\"3px\"> 
                                                             <TR><TD CLASS=\"tabela0_nag1\" STYLE=\"width:35px;\">&nbsp;LP&nbsp;</TD> 
                                                                 <TD CLASS=\"tabela0_nag2\" STYLE=\"width:795px;\">&nbsp;Lista zgłoszonych usterek&nbsp;</TD> 
                                                                 <TD CLASS=\"tabela0_nag2\" STYLE=\"width:69px;\">&nbsp;Nr sali&nbsp;</TD> 
                                                                 <TD CLASS=\"tabela0_nag2\"  STYLE=\"width:30px;\" COLSPAN=\"2\">&nbsp;Opcje&nbsp;</TD> 
                                                             </TR> 
                                                    "; 
                                               $SQL_Info = ""; 
                                               while($SQL_Info = @mysqli_fetch_array($SQL_Query)) { 
                                                 $Licznik++; 
                                                 //Pobierz dane z bazy i wyświetl je w tabeli. 
                                                   echo " 
                                                          <TR CLASS=\"tabela0_wiersz_zaznacz\">
                                                              <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:35px; text-align: right;\">&nbsp;".$Licznik."&nbsp;</TD> 
                                                              <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:795px;\">Komp. nr:&nbsp;".$SQL_Info[8].",&nbsp;".$SQL_Info[2]." 
                                                                  <FONT CLASS=\"tabela-info\"> 
                                                                        <BR/>Kto zgłosił: ".$SQL_Info[3]." 
                                                                        <BR/>Odp.: ".ZnakPytaj($SQL_Info[4])."&nbsp; 
                                                                        <BR/>Data zgłoszenia: ".$SQL_Info[5].",&nbsp;&nbsp; 
                                                                             Data naprawy: ".$SQL_Info[6]." 
                                                                  </FONT> 
                                                              </TD> 
                                                              <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:69px; text-align:right;\" >".$SQL_Info[1]."&nbsp;</TD> 
                                                              <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:21px; text-align:center;\"> 
                                                                  <INPUT TYPE=\"submit\" BORDER=\"0\" NAME=\"fkOdpNapisz\" VALUE=\"".$SQL_Info[0]."\" TITLE=\"Wpisz odpowiedź na zgłoszoną usterkę\" CLASS=\"input_edycja\" /> 
                                                              </TD> 
                                                              <TD CLASS=\"tabela0_wiersz\" STYLE=\"width:14px; text-align:center;\"> 
                                                                  <INPUT TYPE=\"checkbox\" VALUE=\"".$SQL_Info[0]."\" NAME=\"fkRekord[]\" TITLE=\"Zaznacz wiersz, jeśli usterka ma być oznaczona jako naprawiona\"/> 
                                                              </TD> 
                                                          </TR> 
                                                        "; 
                                               } 
                                             //Przycisk pod tabelą. 
                                               echo " 
                                                          <TR STYLE=\"background-color:white;\"> 
                                                              <TD CLASS=\"tabela0_wiersz\" COLSPAN=\"5\" STYLE=\"text-align:right;\"> 
                                                                  <INPUT TYPE=\"submit\" NAME=\"fkNaprawione\" TITLE=\"Oznaczone usterki ustaw jako naprawione\" VALUE=\"Naprawione\" />&nbsp;&nbsp; 
                                                              </TD> 
                                                          </TR> 
                                                      </TABLE> 
                                                  "; 
                                         } else { echo SG_infBrakDanych; } 
                                       } 
                                     } 
                                     @mysqli_close($SQL_Polacz); 
                                   } else { echo SG_infBrakDanych; } 
                            ?> 
                     </FORM> 
                     </CENTER> 
                </DIV> 
           </DIV> 
           <DIV ID="stopka">eUsterki (c)by Jan T. Biernat</DIV> 
      </DIV> 
</BODY> 
</HTML> 