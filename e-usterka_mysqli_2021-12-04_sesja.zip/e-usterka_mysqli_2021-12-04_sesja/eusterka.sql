-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Czas generowania: 28 Kwi 2020, 06:51
-- Wersja serwera: 10.1.16-MariaDB
-- Wersja PHP: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `eusterka`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `usterka_konto`
--

CREATE TABLE `usterka_konto` (
  `konto_id` varchar(16) COLLATE utf8mb4_polish_ci NOT NULL,
  `konto_login` varchar(30) COLLATE utf8mb4_polish_ci NOT NULL,
  `konto_haslo` varchar(41) COLLATE utf8mb4_polish_ci NOT NULL,
  `konto_in` varchar(120) COLLATE utf8mb4_polish_ci NOT NULL,
  `konto_mail` varchar(160) COLLATE utf8mb4_polish_ci NOT NULL,
  `konto_uprawnienia` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `usterka_konto`
--

INSERT INTO `usterka_konto` (`konto_id`, `konto_login`, `konto_haslo`, `konto_in`, `konto_mail`, `konto_uprawnienia`) VALUES
('20200426141001', 'tomek1', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Mirek Kanapka', 'jzakupy@op.pl', 0),
('20200426141002', 'jacek1', '03ed9f0b39f703c2f75d9ce00a84fb210c6fa885', 'Tadziu Lekki', 'jzakupy@op.pl', 0),
('20200426141098', 'janek23', '15346b593c4d0cf05fb6e67a5669d852e6550481', 'Jan T. Biernat', 'janek@op.pl', 1),
('20200426141099', 'kowalski', '52c24d49be8ef49d19f9983b6c3d1c5892c593db', 'Jan Kowalski', 'jzakupy@op.pl', 1);

-- --------------------------------------------------------
-- Hasła zakodowane. 
-- 1234 = 7110eda4d09e062aa5e4a390b0a572ac0d2c0220
-- 0700 = 03ed9f0b39f703c2f75d9ce00a84fb210c6fa885
-- 007  = 15346b593c4d0cf05fb6e67a5669d852e6550481
-- 008  = 52c24d49be8ef49d19f9983b6c3d1c5892c593db
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `usterka_slo_odp`
--

CREATE TABLE `usterka_slo_odp` (
  `odp_id` varchar(16) COLLATE utf8mb4_polish_ci NOT NULL,
  `odp_opis` varchar(255) COLLATE utf8mb4_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `usterka_slo_odp`
--

INSERT INTO `usterka_slo_odp` (`odp_id`, `odp_opis`) VALUES
('20200426095400', 'Przyjąłem do wiadomości.'),
('20200426095401', 'Będzie naprawiony najszybciej jak to możliwe.'),
('20200426095902', 'Niestety nie ma pieniędzy.'),
('20200426095903', 'Niestety nie ma pieniędzy na nowy sprzęt.'),
('20200426095904', 'Nie ma pieniędzy.'),
('20200426095905', 'Nie ma pieniędzy na nowy sprzęt.'),
('20200427095906', 'Przyjdę jutro.'),
('20200426095407', 'Jutro przyjdę.'),
('20200426095408', 'Już idę.'),
('20200426095409', 'Zaraz przyjdę.'),
('20200426095410', 'Jak tylko skończę pracę, to przyjdę.'),
('20200426095411', 'Tylko skończę pracę, to przyjdę.'),
('20200426095412', 'Dzisiaj nie dam rady.'),
('20200426095413', 'Przez cały tydzień mnie nie ma.'),
('20200426095414', 'Teraz nie dam rady.'),
('20200426095415', 'W tej chwili nie dam rady.'),
('20200426095416', 'Poczekaj chwilę.'),
('20200426095417', 'Musisz trochę poczekać.'),
('20200426095418', 'Zaram tam będę.'),
('20200426095419', 'Zaram tam przyjdę.'),
('20200426095420', 'Przyjdę możliwe najszybciej.'),
('20200426095421', 'Przyjdę możliwe najszybciej jak się da.'),
('20200426095422', 'Naprawa rozpocznie się niebawem.'),
('20200426095423', 'Naprawa rozpocznie się wkrótce.'),
('20200426095424', 'Proszę czekać na realizację zgłoszenia.'),
('20200426095425', 'Jestem zajęty. Dzisiaj nie dam rady.'),
('20200426095426', 'Dzisiaj nie dam rady. Jestem zajęty.'),
('20200426095427', 'Przyjdę jak tylko będę mógł.'),
('20200426095497', 'Niestety to tylko sprzęt.'),
('20200426095498', 'To współczuję.'),
('20200426095499', '?');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `usterka_slo`
--

CREATE TABLE `usterka_slo` (
  `usterka_id` varchar(16) COLLATE utf8mb4_polish_ci NOT NULL,
  `usterka_opis` varchar(255) COLLATE utf8mb4_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `usterka_slo`
--

INSERT INTO `usterka_slo` (`usterka_id`, `usterka_opis`) VALUES
('20200426095401', 'Częste zawieszanie się systemu.'),
('20200426095902', 'Komputer nie chce się włączyć.'),
('20200426095903', 'Nie działa myszka lub klawiatura.'),
('20200426095904', 'Nieprawidłowe działanie systemu.'),
('20200426095905', 'Problemy z połączeniem z internetem.'),
('20200426095906', 'Nie działający napęd CD/DVD.'),
('20200426095907', 'Awaria dysku twardego.'),
('20200426095909', 'Komputer nie wykrywa urządzeń USB.'),
('20200426095910', 'Brak dźwięku.'),
('20200426095911', 'Komputer nie ładuje systemu.'),
('20200426095912', 'Komputer włącza się, ale nie wyświetlają się żadne informacje na ekranie (ekran pusty, ciemny).'),
('20200426095913', 'Komputer jest martwy, nie włącza się.'),
('20200426095914', 'Komputer zawiesza się.'),
('20200426095915', 'Komputer po jakimś czasie wyłącza się.'),
('20200426095916', 'Komputer nie widzi drukarki.'),
('20200426095917', 'Brak dostępu do napędu CD-ROM/DVD.'),
('20200426095918', 'Komputer nie wykrywa myszy/klawiatury.'),
('20200426095919', 'Drukarka nie drukuje.'),
('20200426095920', 'Głośna praca komputera.'),
('20200426095921', 'Data i czas jest nieprawidłowy.'),
('20200426095922', 'System nie wykrywa projektora.'),
('20200426095923', 'Projektor nie wyświetla obrazu z komputera.'),
('20200426095924', 'Myszka nie działa.'),
('20200426095925', 'Klawiatura nie działa.'),
('20200426095999', 'Brak sygnału na projektorze.');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `usterka_zglos`
--

CREATE TABLE `usterka_zglos` (
  `zglos_id` varchar(16) COLLATE utf8mb4_polish_ci NOT NULL,
  `zglos_nr_sali` int(3) NOT NULL,
  `zglos_nr_komp` int(3) NOT NULL,
  `zglos_kto` varchar(255) COLLATE utf8mb4_polish_ci NOT NULL,
  `zglos_opis` varchar(255) COLLATE utf8mb4_polish_ci NOT NULL,
  `zglos_odp` varchar(255) COLLATE utf8mb4_polish_ci NOT NULL,
  `zglos_data_zgl` varchar(10) COLLATE utf8mb4_polish_ci NOT NULL,
  `zglos_data_wyk_napr` varchar(10) COLLATE utf8mb4_polish_ci NOT NULL,
  `zglos_naprawiony` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `usterka_zglos`
--

INSERT INTO `usterka_zglos` (`zglos_id`, `zglos_nr_sali`, `zglos_kto`, `zglos_nr_komp`, `zglos_opis`, `zglos_odp`, `zglos_data_zgl`, `zglos_data_wyk_napr`, `zglos_naprawiony`) VALUES
('20200426143801', 318, 'Iwona Piękna', 0, 'Projektor nie wyświetla obrazu z komputera.', 'Zaraz tam będą.', '2020-04-26', '', 1),
('20200427143802', 304, 'Barbara Chętna', 3, 'Data i czas jest nieprawidłowy.', 'Będzie naprawiony najszybciej jak to możliwe.', '2020-04-27', '', 0),
('20200429143803', 304, 'Mirek Kanapka', 18, 'Klawiatura nie działa.', 'Będzie naprawiony najszybciej jak to możliwe.', '2020-04-29', '', 0),
('20200430143804', 102, 'Mirek Kanapka', 7, 'Brak sygnału na projektorze.', 'Zaram tam przyjdę.', '2020-04-30', '', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
