﻿<HTML><HEAD><META CHARSET="utf-8" /> 
<META NAME="keywords" CONTENT="Baza filmów, filmy, baza, baza filmy" /> 
<LINK REL="shortcut icon" HREF="gui/film.ico" /> 
<LINK REL="stylesheet" TYPE="text/css" HREF="gui/style.css" /> 
<TITLE>Baza filmów - Dodaj - w5 (c)by Jan T. Biernat</TITLE> 
</HEAD> 
<?php 
  function ComboBoxLista($NazwaPlikuSLO) { 
    //Generuje listę elementów dla kontrolki/komponentu "SELECT". 
      print("<OPTION>&nbsp;</OPTION>"); 
      if(file_exists($NazwaPlikuSLO)) { 
        //Jeżeli plik istnieje fizycznie na dysku, to wykonaj poniższe instrukcje. 
          $tWiersz = ""; //Utworzenie zmiennej. 
          $tWiersz = file($NazwaPlikuSLO); //Wczytanie zawartości pliku tekstowego 
                                           //i przepisanie danych do zmiennej "$tWiersz". 
          for($I = 0; $I < count($tWiersz); $I++) { 
            print("<OPTION>".$tWiersz[$I]."</OPTION>"); 
          } 
      } else { print("<OPTION>BŁĄD -?Brak pliku tekstowego!</OPTION>"); } 
  } 
?> 
<BODY ONLOAD="document.getElementById('Komponent').focus();"> 
<DIV ID="strona"> 
<FONT CLASS="info_autor"><B><I>Baza filmów - Dodaj - w5 (c)by Jan T. Biernat</I></B></FONT> 
<P ALIGN="center"><BR/><FONT CLASS="tytul"><B><I>Baza filmów</I></B></FONT></P> 
<CENTER> 
   <FORM METHOD="post" ACTION=""> 
         <TABLE BORDER="0"> 
                <TR><TD>&nbsp;Tytuł filmu&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><INPUT TYPE="text" SIZE="45" MAXLENGTH="60" NAME="fkEditTF1" ID="Komponent" /></TD> 
                </TR> 
                <TR><TD>&nbsp;Tytuł filmu PL&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><INPUT TYPE="text" SIZE="45" MAXLENGTH="60" NAME="fkEditTF2" /></TD> 
                </TR> 
                <TR><TD>&nbsp;Gatunek&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><SELECT SIZE="1" NAME="fkGatunek" STYLE="width: 350px;"> 
                                <?php ComboBoxLista("slo-gatunek.slo"); ?> 
                        </SELECT> 
                    </TD> 
                </TR> 
                <TR><TD>&nbsp;Czas (w min.)&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><SELECT SIZE="1" NAME="fkCzas" STYLE="width: 350px;"> 
                                <OPTION>&nbsp;</OPTION> 
                                <OPTION>5</OPTION> 
                                <OPTION>10</OPTION> 
                                <OPTION>15</OPTION> 
                                <OPTION>20</OPTION> 
                                 <OPTION>25</OPTION> 
                                <OPTION>30</OPTION> 
                                <OPTION>45</OPTION> 
                                <OPTION>60</OPTION> 
                                <OPTION>85</OPTION> 
                                <OPTION>120</OPTION> 
                                <OPTION>240</OPTION> 
                                <?php 
                                    for($I = 0; $I < 320; $I++) { 
                                      echo "<OPTION>".($I+1)."</OPTION>"; 
                                    } 
                                ?> 
                        </SELECT></TD> 
                </TR> 
                <TR><TD>&nbsp;Lektor&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><SELECT SIZE="1" NAME="fkLektor" STYLE="width: 350px;"> 
                                <OPTION>&nbsp;</OPTION> 
                                <OPTION>TAK</OPTION> 
                                <OPTION>NIE</OPTION> 
                        </SELECT></TD> 
                </TR> 
                <TR><TD>&nbsp;Nośnik&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><SELECT SIZE="1" NAME="fkNosnik" STYLE="width: 350px;"> 
                                <OPTION>&nbsp;</OPTION> 
                                <OPTION>VHS</OPTION> 
                                <OPTION>CD</OPTION> 
                                <OPTION>VCD</OPTION> 
                                <OPTION>DVD</OPTION> 
                                <OPTION>Blu-ray</OPTION> 
                        </SELECT> 
                    </TD> 
                </TR> 
                <TR><TD>&nbsp;Rok produkcji&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><SELECT SIZE="1" NAME="fkRokP" STYLE="width: 350px;"> 
                                <OPTION>&nbsp;</OPTION> 
                                <?php 
                                    $Rok = 0; 
                                    $Rok = date("Y"); 
                                    do { 
                                      echo "<OPTION>".($Rok--)."</OPTION>"; 
                                    } while($Rok > 1932); 
                                ?> 
                        </SELECT></TD> 
                </TR> 
                <TR><TD>&nbsp;Aktor 1&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><INPUT TYPE="text" SIZE="45" MAXLENGTH="60" NAME="fkAktor1" /></TD> 
                </TR> 
                <TR><TD>&nbsp;Aktor 2&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><INPUT TYPE="text" SIZE="45" MAXLENGTH="60" NAME="fkAktor2" /></TD> 
                </TR> 
                <TR><TD COLSPAN="4" ALIGN="right"> 
                                    <INPUT TYPE="submit" VALUE="Dodaj" NAME="fkPrzyciskDodaj" /> 
                        &nbsp;&nbsp;<INPUT TYPE="reset" VALUE="Wyczyść" />&nbsp;</TD> 
                </TR> 
         </TABLE> 
   </FORM> 
</CENTER> 
<?php 
   //Deklaracja zmiennych tekstowych. 
     $SQL_Polacz = ""; 
     $SQL_Query = ""; 
     $Info = ""; 
     $iLicznik = 0; 
   //Połączenie z bazą. 
     $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); 
     if($SQL_Polacz) { 
       if(@mysqli_select_db($SQL_Polacz, "baza_filmow")) { 
         //Dodaj nowy rekord do bazy "baza filmów". 
         if((isset($_POST['fkPrzyciskDodaj']) == true) 
         &&(strtolower(($_POST['fkPrzyciskDodaj'])) == "dodaj") 
         && (trim($_POST['fkEditTF1']) != "") 
         && (trim($_POST['fkEditTF2']) != "") 
         && (trim($_POST['fkGatunek']) != "") 
         && (trim($_POST['fkCzas']) != "") 
         && (trim($_POST['fkLektor']) != "") 
         && (trim($_POST['fkNosnik']) != "") 
         && (trim($_POST['fkRokP']) != "") 
         && (trim($_POST['fkAktor1']) != "") 
         && (trim($_POST['fkAktor2']) != "")) { 
           //Poniższe instrukcje (czyli dodane danych do bazy) wykonaj, 
           //gdy wszystkie pola w formularzu są wypełnione. 
           $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                     INSERT INTO `filmy` 
                                                     SET `film_id` = '".(date("YmdHis"))."', 
                                                         `film_tytul_org` = '".trim($_POST['fkEditTF1'])."', 
                                                         `film_tytul_pl` = '".trim($_POST['fkEditTF2'])."', 
                                                         `film_gatunek` = '".trim($_POST['fkGatunek'])."', 
                                                         `film_czas_trwania` = '".trim($_POST['fkCzas'])."', 
                                                         `film_lektor` = '".trim($_POST['fkLektor'])."', 
                                                         `film_nosnik` = '".trim($_POST['fkNosnik'])."', 
                                                         `film_rok_prod` = '".trim($_POST['fkRokP'])."', 
                                                         `film_aktor_gl1` = '".trim($_POST['fkAktor1'])."', 
                                                         `film_aktor_gl2` = '".trim($_POST['fkAktor2'])."' 
                                                   "); 
         } 
         //Pobranie danych z bazy i wyświetlenie na ekranie. 
         $SQL_Query = @mysqli_query($SQL_Polacz, ' 
                                                   SELECT DISTINCT `film_id`, 
                                                                   `film_tytul_org`, 
                                                                   `film_tytul_pl`, 
                                                                   `film_gatunek`, 
                                                                   `film_czas_trwania`, 
                                                                   `film_lektor`, 
                                                                   `film_nosnik`, 
                                                                   `film_rok_prod`, 
                                                                   `film_aktor_gl1`, 
                                                                   `film_aktor_gl2` 
                                                   FROM `filmy` 
                                                   ORDER BY `film_tytul_org` ASC 
                                                 '); 
         if($SQL_Query) { 
           if(@mysqli_num_rows($SQL_Query) > 0) { 
             //Jeżeli ilość wierszy zwróconych przez zapytanie 
             //jest większa niż 0, to wykonaj poniższe instrukcje. 
             // 
             //MYSQLI_NUM_ROWS(P) - zwraca liczbę wierszy w wyniku. 
             //                     Instrukcję tę stosuje się tylko 
             //                     przy wykorzystaniu polecenia SELECT. 
             //                     W parametrze P umieszcza się zmienną 
             //                     przechowującą wartość jaką zwróci 
             //                     instrukcja MYSQLI_QUERY. 
               print(" <BR/> 
                       <CENTER> 
                       <TABLE CLASS=\"tabela0\"> 
                              <TR><TD WIDTH=\"25\" CLASS=\"tabela0_nag1\">&nbsp;LP&nbsp;</TD> 
                                  <TD WIDTH=\"299\" CLASS=\"tabela0_nag2\">&nbsp;Tytuł filmu&nbsp;</TD> 
                                  <TD WIDTH=\"299\" CLASS=\"tabela0_nag2\">&nbsp;Tytuł polski filmu&nbsp;</TD> 
                                  <TD WIDTH=\"99\" CLASS=\"tabela0_nag2\">&nbsp;Gatunek&nbsp;</TD> 
                                  <TD WIDTH=\"35\" CLASS=\"tabela0_nag2\">&nbsp;Czas&nbsp;</TD> 
                                  <TD WIDTH=\"55\" CLASS=\"tabela0_nag2\">&nbsp;Lektor&nbsp;</TD> 
                                  <TD WIDTH=\"55\" CLASS=\"tabela0_nag2\">&nbsp;Nośnik&nbsp;</TD> 
                                  <TD WIDTH=\"45\" CLASS=\"tabela0_nag2\">&nbsp;Rok&nbsp;</TD> 
                                  <TD WIDTH=\"155\" CLASS=\"tabela0_nag2\">&nbsp;Aktor 1&nbsp;</TD> 
                                  <TD WIDTH=\"155\" CLASS=\"tabela0_nag2\">&nbsp;Aktor 2&nbsp;</TD> 
                              </TR> 
                     "); 
               $iLicznik = 0; $Info = ""; 
               while($Info = @mysqli_fetch_array($SQL_Query)) { 
                 //Wykonuj pętle tak długo dopóki będą pobierane dane z tabeli. 
                 // 
                 //MYSQLI_FETCH_ARRAY() - Zapisuje wiersz wyniku w tablicy 
                 //                       asocjacyjnej, numerycznej lub w obu. 
                 //                       Jest rozszerzoną wersją MYSQL_FETCH_ROW(). 
                 //                       Oprócz zapisywania danych w indeksach 
                 //                       numerycznych, zapisuje je też w indeksach 
                 //                       przyporządkowujących (tzw. asocjacyjnych), 
                 //                       używając nazw pól jako kluczy. 
                 //                       Jeżeli dwie lub więcej kolumn wyniku ma 
                 //                       te same nazwy, ostatnia kolumna będzie brana 
                 //                       pod uwagę. Dostęp do innych kolumn o tej 
                 //                       samej nazwie jest możliwy jedynie przez 
                 //                       indeksowanie numeryczne. 
                   $iLicznik++; //Inkrementacja zawartości zmiennej o wartość 1, tj. numerowanie kolejnego wiersza. 
                   print(" 
                           <TR CLASS=\"wiersz_zaznacz\">
                               <TD WIDTH=\"25\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: right;\">&nbsp;".$iLicznik."&nbsp;</TD> 
                               <TD WIDTH=\"299\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[1]."&nbsp;</TD> 
                               <TD WIDTH=\"299\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[2]."&nbsp;</TD> 
                               <TD WIDTH=\"99\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[3]."&nbsp;</TD> 
                               <TD WIDTH=\"35\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: right;\">&nbsp;".$Info[4]."&nbsp;</TD> 
                               <TD WIDTH=\"55\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: center;\">&nbsp;".$Info[5]."&nbsp;</TD> 
                               <TD WIDTH=\"55\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: center;\">&nbsp;".$Info[6]."&nbsp;</TD> 
                               <TD WIDTH=\"45\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: right;\">&nbsp;".$Info[7]."&nbsp;</TD> 
                               <TD WIDTH=\"155\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[8]."&nbsp;</TD> 
                               <TD WIDTH=\"155\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[9]."&nbsp;</TD> 
                           </TR> 
                         "); 
               } 
               print(" 
                       </TABLE> 
                       </CENTER> 
                     "); 
           } 
         } 
       } 
       @mysqli_close($SQL_Polacz); 
     } 
?> 
<BR/><BR/> 
</DIV> 
</BODY> 
</HTML> 