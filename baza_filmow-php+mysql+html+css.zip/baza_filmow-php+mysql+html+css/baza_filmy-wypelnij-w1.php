﻿<HTML><HEAD><META CHARSET="utf-8" /> 
<META NAME="keywords" CONTENT="Baza filmów, filmy, baza, baza filmy" /> 
<LINK REL="shortcut icon" HREF="gui/film.ico" /> 
<LINK REL="stylesheet" TYPE="text/css" HREF="gui/style.css" /> 
<TITLE>Baza filmów - Uzupełnij bazę danymi - W1 (c)by Jan T. Biernat</TITLE> 
</HEAD> 
<BODY> 
<DIV ID="strona"> 
<FONT CLASS="info_autor"><B><I>Baza filmów - Uzupełnienie bazy danymi - W1 (c)by Jan T. Biernat</I></B></FONT> 
<BR/> 
<?php 
   //Deklaracja tablic i funkcje. 
     $tTab_FilmTytulOrg[] = "A Bronx Tale"; //Film 1. 
     $tTab_FilmTytulPL[] = "Prawo Bronxu"; 
     $tTab_FilmGatunek[] = "Dramat"; 
     $tTab_FilmCzasTrwania[] = "116"; 
     $tTab_FilmLektor[] = "TAK"; 
     $tTab_FilmNosnik[] = "DVD"; 
     $tTab_FilmRokProd[] = "1993"; 
     $tTab_FilmAktor1[] = "Robert De Niro"; 
     $tTab_FilmAktor2[] = ""; 
 
     $tTab_FilmTytulOrg[] = "Airplane 2: The Sequel"; //Film 2. 
     $tTab_FilmTytulPL[] = "Spokojnie to tylko awaria"; 
     $tTab_FilmGatunek[] = "Komedia"; 
     $tTab_FilmCzasTrwania[] = "81"; 
     $tTab_FilmLektor[] = "TAK"; 
     $tTab_FilmNosnik[] = "VCD"; 
     $tTab_FilmRokProd[] = "1982"; 
     $tTab_FilmAktor1[] = "William Shatner"; 
     $tTab_FilmAktor2[] = ""; 
 
     $tTab_FilmTytulOrg[] = "Alternatywy 4 (1, 2, 3)"; //Film 3. 
     $tTab_FilmTytulPL[] = "Alternatywy 4"; 
     $tTab_FilmGatunek[] = "Komedia"; 
     $tTab_FilmCzasTrwania[] = "162"; 
     $tTab_FilmLektor[] = "TAK"; 
     $tTab_FilmNosnik[] = "DVD"; 
     $tTab_FilmRokProd[] = "1983"; 
     $tTab_FilmAktor1[] = "Roman Wilhelmi"; 
     $tTab_FilmAktor2[] = ""; 
 
     $tTab_FilmTytulOrg[] = "Alternatywy 4 (4, 5, 6)"; //Film 4. 
     $tTab_FilmTytulPL[] = "Alternatywy 4"; 
     $tTab_FilmGatunek[] = "Komedia"; 
     $tTab_FilmCzasTrwania[] = "162"; 
     $tTab_FilmLektor[] = "TAK"; 
     $tTab_FilmNosnik[] = "DVD"; 
     $tTab_FilmRokProd[] = "1983"; 
     $tTab_FilmAktor1[] = "Roman Wilhelmi"; 
     $tTab_FilmAktor2[] = ""; 
 
     $tTab_FilmTytulOrg[] = "Alternatywy 4 (7, 8, 9)"; //Film 5. 
     $tTab_FilmTytulPL[] = "Alternatywy 4"; 
     $tTab_FilmGatunek[] = "Komedia"; 
     $tTab_FilmCzasTrwania[] = "162"; 
     $tTab_FilmLektor[] = "TAK"; 
     $tTab_FilmNosnik[] = "DVD"; 
     $tTab_FilmRokProd[] = "1983"; 
     $tTab_FilmAktor1[] = "Roman Wilhelmi"; 
     $tTab_FilmAktor2[] = ""; 
 
     $tTab_FilmTytulOrg[] = "Art of War"; //Film 6. 
     $tTab_FilmTytulPL[] = "Zasady walki"; 
     $tTab_FilmGatunek[] = "Sensacyjny"; 
     $tTab_FilmCzasTrwania[] = "117"; 
     $tTab_FilmLektor[] = "TAK"; 
     $tTab_FilmNosnik[] = "DVD"; 
     $tTab_FilmRokProd[] = "2000"; 
     $tTab_FilmAktor1[] = "Wesley Snipes"; 
     $tTab_FilmAktor2[] = ""; 
 
   //Połączenie z serwerem. 
     $Polacz = @mysqli_connect('localhost', 'root', ''); 
     if($Polacz) { 
       @mysqli_set_charset($SQL_Polacz, "utf8"); 
       echo "<BR/>Nastąpiło połączenie z serwerem."; 
       if(@mysqli_select_db($Polacz, 'baza_filmow')) { 
         //Wypełnienie bazy danymi. 
           $tSQL = ""; 
           for($I = 0; $I < count($tTab_FilmTytulOrg); $I++) { 
             $tSQL = ""; $tSQL = "INSERT INTO `filmy` 
                                  SET `film_id` = '".(date("YmdHi")).($I+1)."', 
                                      `film_tytul_org` = '".trim($tTab_FilmTytulOrg[$I])."', 
                                      `film_tytul_pl` = '".trim($tTab_FilmTytulPL[$I])."', 
                                      `film_gatunek` = '".trim($tTab_FilmGatunek[$I])."', 
                                      `film_czas_trwania` = '".trim($tTab_FilmCzasTrwania[$I])."', 
                                      `film_lektor` = '".trim($tTab_FilmLektor[$I])."', 
                                      `film_nosnik` = '".trim($tTab_FilmNosnik[$I])."', 
                                      `film_rok_prod` = '".trim($tTab_FilmRokProd[$I])."', 
                                      `film_aktor_gl1` = '".trim($tTab_FilmAktor1[$I])."', 
                                      `film_aktor_gl2` = '".trim($tTab_FilmAktor2[$I])."'"; 
             echo "<BR/><BR/> ->".$tSQL; //Wyświetl zapytanie SQL na ekranie. 
             if(@mysqli_query($Polacz, $tSQL)) { 
               echo "<BR/>Rekord nr ".($I+1)." został dodany."; 
             } else { echo "<BR/>BŁĄD -?Nie mogę wprowadzić danych do bazy!"; } 
           } 
       } else { echo "<BR/>BŁĄD -?Nie mogę wybrać bazy!"; } 
       @mysqli_close($Polacz); 
     } else { print("<BR/>BŁĄD -?Brak połączenie z serwerem!"); } 
     //Zapytanie SQL. 
?> 
<BR/><BR/> 
</DIV> 
</BODY> 
</HTML> 