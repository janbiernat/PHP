﻿<HTML><HEAD><META CHARSET="utf-8" /> 
<META NAME="keywords" CONTENT="Baza filmów, filmy, baza, baza filmy" /> 
<LINK REL="shortcut icon" HREF="gui/film.ico" /> 
<LINK REL="stylesheet" TYPE="text/css" HREF="gui/style.css" /> 
<TITLE>Baza filmów - Uzupełnij bazę, danymi z pliku tekstowego - W2 (c)by Jan T. Biernat</TITLE> 
</HEAD> 
<BODY> 
<DIV ID="strona"> 
<FONT CLASS="info_autor"><B><I>Baza filmów - Uzupełnienie bazy, danymi pobranymi z pliku tekstowego - W2 (c)by Jan T. Biernat</I></B></FONT> 
<BR/> 
<?php 
   //Zadeklarowanie stałych. 
     define("SG_tNazwaPliku", "baza_filmy.csv"); 
   //Popranie danych z pliku tekstowego. 
     if(file_exists(SG_tNazwaPliku)) { 
       $tWiersz = ""; //Utworzenie zmiennej. 
       $tWiersz = file(SG_tNazwaPliku); //Wczytanie zawartości pliku tekstowego 
                                      //i przepisanie danych do zmiennej "$tWiersz". 
       //Połączenie z serwerem. 
         $Polacz = @mysqli_connect('localhost', 'root', ''); 
         if($Polacz) { 
           @mysqli_set_charset($Polacz, "utf8"); 
           echo "<BR/>Nastąpiło połączenie z serwerem."; 
           if(@mysqli_select_db($Polacz, 'baza_filmow')) { 
             //Wypełnienie bazy danymi. 
               $tSQL = ""; $tDane = ""; //Utworzenie zmiennych. 
               for($I = 0; $I < count($tWiersz); $I++) { 
                 $tDane = ""; //Wyczyść zmienną. 
                 $tDane = explode(";", $tWiersz[$I]); //Rozdziel dane. 
                 $tSQL = ""; $tSQL = "INSERT INTO `filmy` 
                                      SET `film_id` = '".(date("YmdHi")).($I+1)."', 
                                          `film_tytul_org` = '".trim($tDane[1])."', 
                                          `film_tytul_pl` = '".trim($tDane[2])."', 
                                          `film_gatunek` = '".trim($tDane[3])."', 
                                          `film_czas_trwania` = '".trim($tDane[4])."', 
                                          `film_lektor` = '".trim($tDane[5])."', 
                                          `film_nosnik` = '".trim($tDane[6])."', 
                                          `film_rok_prod` = '".trim($tDane[7])."', 
                                          `film_aktor_gl1` = '".trim($tDane[8])."', 
                                          `film_aktor_gl2` = '".trim($tDane[9])."'"; 
                 echo "<BR/><BR/> >".$tSQL;  //Wyświetl zapytanie SQL na ekranie. 
                 if(@mysqli_query($Polacz, $tSQL)) { 
                   echo "<BR/>Rekord nr ".($I+1)." został dodany."; 
                 } else { echo "<BR/>BŁĄD -?Nie mogę wprowadzić danych do bazy!"; } 
               } 
           } else { echo "<BR/>BŁĄD -?Nie mogę wybrać bazy!"; } 
           @mysqli_close($Polacz); 
         } else { print("<BR/>BŁĄD -?Brak połączenie z serwerem!"); } 
     } 
?> 
<BR/><BR/> 
</DIV> 
</BODY> 
</HTML> 