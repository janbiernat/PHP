-- phpMyAdmin SQL Dump 
-- version 4.5.1 
-- http://www.phpmyadmin.net 
-- 
-- Host: 127.0.0.1 
-- Czas generowania: 18 Wrz 2018, 12:24 
-- Wersja serwera: 10.1.16-MariaDB 
-- Wersja PHP: 5.6.24 
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO"; 
SET time_zone = "+00:00"; 
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */; 
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */; 
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */; 
/*!40101 SET NAMES utf8mb4 */; 
-- 
-- Baza danych: `baza_filmy` 
-- 
-- -------------------------------------------------------- 
-- 
-- Struktura tabeli dla tabeli `filmy` 
-- 
CREATE TABLE `filmy` ( 
  `film_id` int(10) NOT NULL, 
  `film_tytul_org` text NOT NULL, 
  `film_tytul_pl` text, 
  `film_gatunek` text, 
  `film_czas_trwania` int(4), 
  `film_lektor` char(3), 
  `film_nosnik` char(3), 
  `film_rok_prod` year(4), 
  `film_aktor_gl1` text, 
  `film_aktor_gl2` text 
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 
-- 
-- Zrzut danych tabeli `filmy` 
-- 
INSERT INTO `filmy` (`film_id`, `film_tytul_org`, `film_tytul_pl`, `film_gatunek`, `film_czas_trwania`, `film_lektor`, `film_nosnik`, `film_rok_prod`, `film_aktor_gl1`, `film_aktor_gl2`) VALUES 
(1, 'A Bronx Tale', 'Prawo Bronxu', 'Dramat', 116, 'TAK', 'DVD', 1993, 'Robert De Niro', ''), 
(2, 'Air America', 'Air America', 'Akcja', 107, 'TAK', 'DVD', 1990, 'Mel Gibson', ''), 
(3, 'Airplane 2: The Sequel', 'Spokojnie to tylko awaria', 'Komedia', 81, 'TAK', 'VCD', 1982, 'William Shatner', ''), 
(4, 'Alternatywy 4 (1, 2, 3)', 'Alternatywy 4', 'Komedia', 162, 'TAK', 'DVD', 1983, 'Roman Wilhelmi', ''), 
(5, 'Alternatywy 4 (4, 5, 6)', 'Alternatywy 4', 'Komedia', 162, 'TAK', 'DVD', 1983, 'Roman Wilhelmi', ''), 
(6, 'Alternatywy 4 (7, 8, 9)', 'Alternatywy 4', 'Komedia', 162, 'TAK', 'DVD', 1983, 'Roman Wilhelmi', ''), 
(7, 'Art of War', 'Zasady walki', 'Sensacyjny', 117, 'TAK', 'DVD', 2000, 'Wesley Snipes', ''), 
(8, 'Asterix & Obelix Contre Cesar', 'Asterix i Obelix Kontra Cezar', 'Komedia', 105, 'TAK', 'DVD', 2000, 'Christian Clavier', 'Gérard Depardieu'), 
(9, 'Asterix & Obelix Mission Cleopatre', 'Asterix i Obelix Misja Kleopatra', 'Komedia', 104, 'TAK', 'DVD', 2002, 'Christian Clavier', 'Gérard Depardieu'), 
(10, 'Automatic', 'Android', 'Fantastyczny', 90, 'TAK', 'DVD', 1994, 'Olivier Gruner', ''), 
(11, 'Best of The Best 2', 'Najlepszy z najlepszych 2', 'Karate', 100, 'TAK', 'VCD', 1993, 'Eric Roberts', ''), 
(12, 'Beverly hills cop 2', 'Gliniarz Beverly Hills 2', 'Komedia sensacyjna', 99, 'TAK', 'VCD', 1987, 'Eddie Murphy', ''), 
(13, 'Bowling for columbine', 'Zabawy z bronią', 'Dokument', 114, 'TAK', 'DVD', 2002, 'Michael Moore <- Reżyser', ''), 
(14, 'Casper', 'Kacper - początek straszenia', 'Komedia', 90, 'TAK', 'DVD', 1997, 'Steve Guttenberg', ''), 
(15, 'City by the Sea', 'Dochodzenie', 'Dramat', 105, 'TAK', 'DVD', 2002, 'Robert De Niro', ''), 
(16, 'Crocodile DUNDEE', 'Krokodyl DUNDEE', 'Przygodowy', 94, 'TAK', 'VCD', 1986, 'Paul Hogan', ''), 
(17, 'Crocodile DUNDEE 2', 'Krokodyl DUNDEE 2', 'Przygodowy', 107, 'TAK', 'VCD', 1988, 'Paul Hogan', ''), 
(18, 'Dances with wolves', 'Tańczący z wilkami', 'Western', 226, 'TAK', 'DVD', 1990, 'Kevin Costner', ''), 
(19, 'Domestic disturbance', 'Teren prywatny', 'Thriller', 90, 'TAK', 'DVD', 2001, 'John Travolta', ''), 
(20, 'Droga do domu Ojca', 'Droga do domu Ojca', 'Dokument', 27, 'TAK', 'DVD', 2006, 'Jan Paweł 2 - Karol Wojtyła', ''), 
(21, 'Equilibrium', 'Równowaga', 'Fantastyczny', 102, 'TAK', 'DVD', 2002, 'Christian Bale', ''), 
(22, 'Fahrenheit 9.11', 'Fahrenheit 9.11', 'Dokument', 112, 'TAK', 'DVD', 2004, 'George W. Bush', ''), 
(23, 'For queen and country', 'Za królową i ojczyznę', 'Dramat', 105, 'TAK', 'DVD', 1988, 'Denzel Washington', ''), 
(24, 'Good Will Hunting', 'Buntownik z wyboru', 'Dramat', 121, 'TAK', 'DVD', 1997, 'Matt Damon', 'Robin Williams'), 
(25, 'Gun shy', 'Z zimną krwią', 'Sensacyjny', 97, 'TAK', 'DVD', 1998, 'Michael Wincott', ''), 
(26, 'Halo Szpicbródka', 'Halo Szpicbródka', 'Katastroficzny', 105, 'TAK', 'DVD', 1978, 'Piotr Fronczewski', ''), 
(27, 'Hellbound', 'Piekielne starcie', 'Thriller', 95, 'TAK', 'DVD', 1994, 'Chuck Norris', ''), 
(28, 'Hitcher', 'Autostopowicz', 'Thriller', 93, 'TAK', 'DVD', 1986, 'Rutger Hauer', ''), 
(29, 'Jaws 2', 'Szczęki 2', 'Sensacyjny', 111, 'TAK', 'DVD', 1978, 'Roy Scheider', ''), 
(30, 'Karol - A man who became POPE', 'Karol - Człowiek, który został PAPIEŻEM', 'Dramat biograficzny', 186, 'TAK', 'DVD', 2005, 'Piotr Adamczyk', ''), 
(31, 'Karol - The Pope, The Man', 'Karol - Papież, który pozostał człowiekiem', 'Dramat biograficzny', 153, 'TAK', 'DVD', 2006, 'Piotr Adamczyk', ''), 
(32, 'Kiler', 'Kiler', 'Komedia sensacyjna', 120, 'TAK', 'DVD', 1997, 'Cezary Pazura', 'Jerzy Stuhr'), 
(33, 'King Solomon`s Mines', 'Kopalnie Króla Salomona', 'Przygodowy', 177, 'TAK', 'DVD', 2004, 'Patrick Swayze', ''), 
(34, 'Kiss the girls', 'Kolekcjoner', 'Kryminał', 90, 'TAK', 'VCD', 1997, 'Morgan Freeman', ''), 
(35, 'Konsul', 'Konsul', 'Komedia sensacyjna', 104, 'TAK', 'DVD', 1989, 'Piotr Fronczewski', ''), 
(36, 'Life is Beautiful (La Vita e Bella)', 'Życie jest piękne', 'Dramat', 111, 'TAK', 'DVD', 1997, 'Roberto Benigni', ''), 
(37, 'Million dollar baby', 'Za wszelką cenę', 'Dramat', 137, 'TAK', 'DVD', 2004, 'Clint Eastwood', ''), 
(38, 'Niezwykłe miejsca', 'Niezwykłe miejsca', 'Przyrodniczy', 40, 'NIE', 'DVD', 2005, '???', ''), 
(39, 'No good deed', 'Zakładnik', 'Thriller', 103, 'TAK', 'DVD', 2002, 'Samuel L. Jackson', ''), 
(40, 'Nocna zmiana', 'Nocna zmiana', 'Dokument', 61, 'TAK', 'DVD', 1994, 'Jacek Kurski <- Reżyser', ''), 
(41, 'Nuit de noces', 'Moje wielkie kanadyjskie... wesele', 'Komedia', 90, 'TAK', 'DVD', 2003, '???', ''), 
(42, 'Open Range', 'Bezprawie', 'Western', 139, 'TAK', 'DVD', 2005, 'Costner Kevin', ''), 
(43, 'Out of time', 'Wyścig z czasem', 'Sensacyjny', 90, 'TAK', 'DVD', 2000, 'Denzel Washington', ''), 
(44, 'Pogoda na jutro', 'Pogoda na jutro', 'Obyczajowy', 96, 'TAK', 'DVD', 2003, 'Jerzy Stuhr', ''), 
(45, 'Prymas - trzy lata z tysiąca', 'Prymas - trzy lata z tysiąca', 'Dramat', 103, 'TAK', 'DVD', 2000, 'Andrzej Seweryn', ''), 
(46, 'Quo Vadis', 'Quo Vadis', 'Historyczny', 172, 'TAK', 'DVD', 2001, 'Michał Bajor', 'Bogusław Linda'), 
(47, 'RAMBO - First blood', 'RAMBO - Pierwsza krew', 'Wojenny', 90, 'TAK', 'DVD', 1982, 'Sylvester Stallone', ''), 
(48, 'RAMBO - First blood 2', 'RAMBO - Pierwsza krew 2', 'Wojenny', 98, 'TAK', 'DVD', 1985, 'Sylvester Stallone', ''), 
(49, 'Saints and Soldiers', 'Na tyłach wroga', 'Wojenny', 90, 'TAK', 'DVD', 2004, 'Corbin Allred', ''), 
(50, 'Seksmisja', 'Seksmisja', 'Komedia', 90, 'TAK', 'VCD', 1976, 'Jerzy Stuhr', ''), 
(51, 'Show', 'Show', 'Komedia', 123, 'TAK', 'DVD', 2003, 'Cezary Pazura', 'Jerzy Stuhr'), 
(52, 'Shrek 1', 'Shrek 1', 'Animowany', 95, 'TAK', 'DVD', 2001, 'Mike Myers', 'Eddie Murphy'), 
(53, 'Shrek 2', 'Shrek 2', 'Animowany', 105, 'TAK', 'DVD', 2004, 'Mike Myers', 'Eddie Murphy'), 
(54, 'Smoke', 'Dym', 'Obyczajowy', 108, 'TAK', 'DVD', 1995, 'William Hurt', 'Harvey Keitel'), 
(55, 'Solidarność LIVE Gdańsk 2006 - Koncert', 'Solidarność LIVE Gdańsk 2006 - Koncert', 'Koncert', 124, 'NIE', 'DVD', 2006, 'Jean Michel Jarre <- kompozytor', ''), 
(56, 'Star Wars - A New Hope', 'Star Wars - Nowa nadzieja', 'Fantastyczny', 120, 'NIE', 'DVD', 1977, 'Harrison Ford', ''), 
(57, 'Star Wars - Return of the Jedi', 'Star Wars - Powrót Jedi', 'Fantastyczny', 131, 'NIE', 'DVD', 1983, 'Harrison Ford', ''), 
(58, 'Star Wars - The Empire Strikes Back', 'Star Wars - Imperium kontratakuje', 'Fantastyczny', 124, 'NIE', 'DVD', 1980, 'Harrison Ford', ''), 
(59, 'Stargate', 'Gwiezdne wrota', 'Fantastyczny', 90, 'TAK', 'DVD', 1994, 'Kurt Russell', 'James Spader'), 
(60, 'Steel Dawn', 'Stalowy świt', 'Fantastyczny', 102, 'TAK', 'DVD', 1987, 'Patrick Swayze', ''), 
(61, 'Super size me', 'Czy wiesz, co jesz?', 'Dokument', 96, 'TAK', 'DVD', 2004, 'Morgan Spurlock <- Reżyser', ''), 
(62, 'Tais Toi', 'Przyjaciel gangstera', 'Komedia sensacyjna', 83, 'TAK', 'DVD', 2003, 'Jean Reno', 'Gerard Depardieu'), 
(63, 'Taxi', 'Taksówka', 'Komedia', 86, 'TAK', 'DVD', 1998, 'Samy Naceri', ''), 
(64, 'Terminator 2', 'Elektroniczny morderca 2', 'Fantastyczny', 131, 'TAK', 'DVD', 1991, 'Arnold Schwarzenegger', ''), 
(65, 'The Hitman', 'Zabójca', 'Sensacyjny', 95, 'TAK', 'DVD', 1991, 'Chuck Norris', ''), 
(66, 'The Shawshank redemption', 'Skazany na Shawshank', 'Dramat', 140, 'TAK', 'DVD', 1994, 'Tim Robbins', 'Morgan Freeman'), 
(67, 'The Sixth Sense', 'Szósty zmysł', 'Thriller', 103, 'TAK', 'DVD', 1999, 'Bruce Willis', ''), 
(68, 'The Skulls', 'Sekta', 'Dramat sensacyjny', 90, 'NIE', 'DVD', 1999, 'Joshua Jackson', 'Paul Walker'), 
(69, 'Total Recall', 'Pamięć absolutna', 'Fantastyczny', 120, 'TAK', 'DVD', 1990, 'Arnold Schwarzenegger', ''), 
(70, 'Traces of red', 'Podpis mordercy', 'Kryminał', 105, 'TAK', 'DVD', 1992, 'James Belushi', ''), 
(71, 'Trading Places', 'Nieoczekiwana zmiana miejsc', 'Komedia', 111, 'TAK', 'DVD', 1983, 'Dan Aykroyd', 'Eddie Murphy'), 
(72, 'Twister', 'Twister', 'Katastroficzny', 108, 'TAK', 'DVD', 1996, 'Helen Hunt', 'Bill Paxton'), 
(73, 'Vabank', 'Vabank', 'Komedia', 90, 'TAK', 'VCD', 1975, 'Jan Machulski', ''), 
(74, 'Vinci', 'Vinci', 'Komedia sensacyjna', 90, 'TAK', 'DVD', 2000, 'Jan Machulski', ''), 
(75, 'Walking tall', 'Z podniesionym czołem', 'Sensacyjny', 86, 'TAK', 'DVD', 2000, 'The Rock', ''), 
(76, 'Wasabi', 'Wasabi - Hubert zawodowiec', 'Komedia sensacyjna', 90, 'TAK', 'DVD', 2001, 'Jean Reno', 'Ryôko Hirosue i Michel Muller'), 
(77, 'We were soldiers', 'Byliśmy żołnierzami', 'Wojenny', 135, 'TAK', 'DVD', 2002, 'Mel Gibson', ''), 
(78, 'Wrong turn', 'Droga bez odwrotu', 'Horror', 80, 'TAK', 'DVD', 2003, 'Desmond Harrington', ''), 
(79, 'Wrongfully Accused', 'Ściągany', 'Komedia', 87, 'TAK', 'DVD', 1998, 'Leslie Nielsen', ''), 
(80, 'Zakazane piosenki - Skarby Polskiego Kina', 'Zakazane piosenki - Skarby Polskiego Kina', 'Wojenny', 100, 'TAK', 'DVD', 1955, 'Jerzy Duszyński', 'Danuta Szafrańska'); 
-- 
-- Indeksy dla zrzutów tabel 
-- 
-- Indexes for table `filmy` 
-- 
ALTER TABLE `filmy` ADD PRIMARY KEY (`film_id`); 
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */; 
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */; 
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */; 