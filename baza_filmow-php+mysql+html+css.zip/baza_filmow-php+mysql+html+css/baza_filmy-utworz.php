﻿<HTML><HEAD><META CHARSET="utf-8" /> 
<META NAME="keywords" CONTENT="Baza filmów, filmy, baza, baza filmy" /> 
<LINK REL="shortcut icon" HREF="gui/film.ico" /> 
<LINK REL="stylesheet" TYPE="text/css" HREF="gui/style.css" /> 
<TITLE>Baza filmów - Utwórz bazę (c)by Jan T. Biernat</TITLE> 
</HEAD> 
<BODY> 
<DIV ID="strona"> 
<FONT CLASS="info_autor"><B><I>Baza filmów - Utworzenie bazy filmów (c)by Jan T. Biernat</I></B></FONT> 
<BR/> 
<?php //MySQL. 
   $Polacz = @mysqli_connect('localhost', 'root', ''); 
   if($Polacz) { 
     echo "<BR/>Nastąpiło połączenie z serwerem."; 
     //Zapytanie SQL. 
       $tSQL = ""; $tSQL = "CREATE DATABASE `baza_filmow`"; 
     //Wykonanie zapytania SQL. 
     if(@mysqli_query($Polacz, $tSQL)) { 
       echo "<BR/>Baza danych została utworzona."; 
       if(@mysqli_select_db($Polacz, 'baza_filmow')) { 
         //Po wybraniu bazy "baza_filmow" wykonaj poniższe instrukcje. 
           echo "<BR/>Została wybrana baza."; 
         //Zapytanie SQL. 
           $tSQL = ""; $tSQL = "CREATE TABLE `filmy` 
                                ( 
                                 `film_id` char(15) NOT NULL, 
                                 `film_tytul_org` text NOT NULL, 
                                 `film_tytul_pl` text, 
                                 `film_gatunek` text, 
                                 `film_czas_trwania` int(4), 
                                 `film_lektor` char(3), 
                                 `film_nosnik` char(9), 
                                 `film_rok_prod` year(4), 
                                 `film_aktor_gl1` text, 
                                 `film_aktor_gl2` text, 
                                 PRIMARY KEY(`film_id`) 
                                )"; 
           if(@mysqli_query($Polacz, $tSQL)) { 
             echo "<BR/>Tabela została utworzona."; 
             //Ustawienie kodowania dla tabeli w bazie danych MySQL. 
               $tSQL = ""; $tSQL = "ALTER TABLE `filmy` DEFAULT CHARACTER SET 'utf8' COLLATE 'utf8_general_ci'"; 
               if(@mysqli_query($Polacz, $tSQL)) { print("<BR/>Kodowanie polskich znaków dla tabeli jest ustawione."); } 
               else { print("<BR/>BŁĄD -?Brak kodowania polskich znaków dla tabeli!"); } 
           } else { echo "<BR/>BŁĄD -?Nie mogę utworzyć tabeli!"; } 
       } else { echo "<BR/>BŁĄD -?Nie mogę wybrać bazy!"; } 
     } else { echo "<BR/>BŁĄD -?Nie mogłem utworzyć bazy!"; } 
     @mysqli_close($Polacz); 
   } else { print("<BR/>BŁĄD -?Brak połączenie z serwerem!"); } 
?> 
</DIV> 
</BODY> 
</HTML> 