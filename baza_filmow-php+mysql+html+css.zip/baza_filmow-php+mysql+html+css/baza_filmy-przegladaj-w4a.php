﻿<HTML><HEAD><META CHARSET="utf-8" /> 
<META NAME="keywords" CONTENT="Baza filmów, filmy, baza, baza filmy" /> 
<LINK REL="shortcut icon" HREF="gui/film.ico" /> 
<LINK REL="stylesheet" TYPE="text/css" HREF="gui/style.css" /> 
<TITLE>Baza filmów - Przeglądanie filmów - w4a (c)by Jan T. Biernat</TITLE> 
</HEAD> 
<?php 
  function ComboBoxLista($tListaElementow) { 
    //Generuje listę elementów dla kontrolki/komponentu "SELECT". 
      print("<OPTION>&nbsp;</OPTION>"); 
      for($I = 0; $I < count($tListaElementow); $I++) { 
        print("<OPTION>".$tListaElementow[$I]."</OPTION>"); 
      } 
  } 
?> 
<BODY ONLOAD="document.getElementById('Komponent').focus();"> 
<DIV ID="strona"> 
<FONT CLASS="info_autor"><B><I>Baza filmów - Przeglądanie filmów - w4a (c)by Jan T. Biernat</I></B></FONT> 
<P ALIGN="center"><BR/><FONT CLASS="tytul"><B><I>Baza filmów</I></B></FONT></P> 
<CENTER> 
   <FORM METHOD="post" ACTION="baza_filmy-przegladaj-w4a.php"> 
         <TABLE BORDER="0"> 
                <TR><TD>&nbsp;Podaj tekst<SUP><FONT STYLE="font-size: 8pt; color: blue; cursor: help;" TITLE="Wyświetlone zostaną dane, które rozpoczynają się od wpisanych znaków.">?</FONT></SUP>&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><INPUT TYPE="text" SIZE="25" MAXLENGTH="60" NAME="fkEdit" ID="Komponent"></TD> 
                </TR> 
                <TR><TD>&nbsp;Wybierz kolumnę do przeszukania&nbsp;</TD> 
                    <TD>&nbsp;:&nbsp;</TD> 
                    <TD><SELECT SIZE="1" NAME="fkComboBox" STYLE="width: 209px;"> 
                                <?php 
                                   $Element[] = "Tytuł filmu"; 
                                   $Element[] = "Tytuł polski filmu"; 
                                   $Element[] = "Gatunek"; 
                                   $Element[] = "Czas"; 
                                   $Element[] = "Lektor"; 
                                   $Element[] = "Nośnik"; 
                                   $Element[] = "Rok"; 
                                   $Element[] = "Aktor 1"; 
                                   ComboBoxLista($Element); 
                                ?> 
                        </SELECT> 
                    </TD> 
                </TR> 
                <TR><TD COLSPAN="4" ALIGN="right"> 
                                    <INPUT TYPE="submit" VALUE="Szukaj"> 
                        &nbsp;&nbsp;<INPUT TYPE="reset" VALUE="Wyczyść">&nbsp;</TD> 
                </TR> 
         </TABLE> 
   </FORM> 
</CENTER> 
<?php 
   //Deklaracja zmiennych tekstowych. 
     $SQL_Polacz = ""; 
     $SQL_Query = ""; 
     $Info = ""; 
     $SQL_Sort = ""; 
     $iLicznik = 0; 
     $SQL_KolumnaNazwa = ""; 
   //Wybranie kolumny wg której nastąpi przeszukanie danych. 
     if(isset($_POST['fkComboBox']) == true) { 
       //Jeżeli zmienna tablicowa "$_POST['fkComboBox']" została utworzona, 
       //to wykonaj poniższe instrukcje. 
       // 
       //Funkcja "ISSET()" - sprawdza, czy zmienna została utworzona. 
       //Jeżeli zmienna istnieje to funkcja "isset" zwraca prawdę (tj. true). 
         if(strtolower("Tytuł filmu") == trim(strtolower($_POST['fkComboBox']))) { $SQL_KolumnaNazwa = "film_tytul_org"; } 
         else if(strtolower("Tytuł polski filmu") == trim(strtolower($_POST['fkComboBox']))) { $SQL_KolumnaNazwa = "film_tytul_pl"; } 
              else if(strtolower("Gatunek") == trim(strtolower($_POST['fkComboBox']))) { $SQL_KolumnaNazwa = "film_gatunek"; } 
                   else if(strtolower("Czas") == trim(strtolower($_POST['fkComboBox']))) { $SQL_KolumnaNazwa = "film_czas_trwania"; } 
                        else if(strtolower("Lektor") == trim(strtolower($_POST['fkComboBox']))) { $SQL_KolumnaNazwa = "film_lektor"; } 
                             else if(strtolower("Nośnik") == trim(strtolower($_POST['fkComboBox']))) { $SQL_KolumnaNazwa = "film_nosnik"; } 
                                  else if(strtolower("Rok") == trim(strtolower($_POST['fkComboBox']))) { $SQL_KolumnaNazwa = "film_rok_prod"; } 
                                       else if(strtolower("Aktor 1") == trim(strtolower($_POST['fkComboBox']))) { $SQL_KolumnaNazwa = "film_aktor_gl1"; } 
                                            else { $SQL_KolumnaNazwa = "film_tytul_org"; } 
     } else { $SQL_KolumnaNazwa = "film_tytul_org"; } 
   //Skrypt PHP. 
     $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); 
     if($SQL_Polacz) { 
       if(@mysqli_select_db($SQL_Polacz, "baza_filmow")) { 
         //Sortowanie danych. 
           if(isset($_GET['sort']) == true) { 
             //Jeżeli zmienna tablicowa "$_GET['sort']" została utworzona, 
             //to wykonaj poniższe instrukcje. 
             // 
             //Funkcja "ISSET()" - sprawdza, czy zmienna została utworzona. 
             //Jeżeli zmienna istnieje to funkcja "isset" zwraca prawdę (tj. true). 
               if($_GET['sort'] == 1) { $SQL_Sort = "`film_tytul_org`"; } 
               else if($_GET['sort'] == 2) { $SQL_Sort = "`film_tytul_pl`"; } 
                    else if($_GET['sort'] == 3) { $SQL_Sort = "`film_gatunek`"; } 
                         else if($_GET['sort'] == 4) { $SQL_Sort = "`film_czas_trwania`"; } 
                              else if($_GET['sort'] == 5) { $SQL_Sort = "`film_lektor`"; } 
                                   else if($_GET['sort'] == 6) { $SQL_Sort = "`film_nosnik`"; } 
                                        else if($_GET['sort'] == 7) { $SQL_Sort = "`film_rok_prod`"; } 
                                             else if($_GET['sort'] == 8) { $SQL_Sort = "`film_aktor_gl1`"; } 
                                                  else { $SQL_Sort = "`film_tytul_org`"; } 
           } else { $SQL_Sort = "`film_tytul_org`"; } 
         //Wykonanie zapytania. 
           $SQL_Query = @mysqli_query($SQL_Polacz, " 
                                                     SELECT DISTINCT `film_id`, 
                                                                     `film_tytul_org`, 
                                                                     `film_tytul_pl`, 
                                                                     `film_gatunek`, 
                                                                     `film_czas_trwania`, 
                                                                     `film_lektor`, 
                                                                     `film_nosnik`, 
                                                                     `film_rok_prod`, 
                                                                     `film_aktor_gl1`, 
                                                                     `film_aktor_gl2` 
                                                     FROM `filmy` 
                                                     WHERE LOWER(`".$SQL_KolumnaNazwa."`) LIKE LOWER('".$_POST['fkEdit']."%') 
                                                     ORDER BY $SQL_Sort ASC 
                                                   "); 
         if($SQL_Query) { 
           if(@mysqli_num_rows($SQL_Query) > 0) { 
             //Jeżeli ilość wierszy zwróconych przez zapytanie 
             //jest większa niż 0, to wykonaj poniższe instrukcje. 
             // 
             //MYSQLI_NUM_ROWS(P) - zwraca liczbę wierszy w wyniku. 
             //                     Instrukcję tę stosuje się tylko 
             //                     przy wykorzystaniu polecenia SELECT. 
             //                     W parametrze P umieszcza się zmienną 
             //                     przechowującą wartość jaką zwróci 
             //                     instrukcja MYSQLI_QUERY. 
               print(" <BR/> 
                       <CENTER> 
                       <TABLE CLASS=\"tabela0\"> 
                              <TR><TD WIDTH=\"25\" CLASS=\"tabela0_nag1\">&nbsp;LP&nbsp;</TD> 
                                  <TD WIDTH=\"299\" CLASS=\"tabela0_nag2\">&nbsp;<A CLASS=\"tabela0_nag_txt\" HREF=\"baza_filmy-przegladaj-w4a.php?sort=1\">Tytuł filmu</A>&nbsp;</TD> 
                                  <TD WIDTH=\"299\" CLASS=\"tabela0_nag2\">&nbsp;<A CLASS=\"tabela0_nag_txt\" HREF=\"baza_filmy-przegladaj-w4a.php?sort=2\">Tytuł polski filmu</A>&nbsp;</TD> 
                                  <TD WIDTH=\"99\" CLASS=\"tabela0_nag2\">&nbsp;<A CLASS=\"tabela0_nag_txt\" HREF=\"baza_filmy-przegladaj-w4a.php?sort=3\">Gatunek</A>&nbsp;</TD> 
                                  <TD WIDTH=\"35\" CLASS=\"tabela0_nag2\">&nbsp;<A CLASS=\"tabela0_nag_txt\" HREF=\"baza_filmy-przegladaj-w4a.php?sort=4\">Czas</A>&nbsp;</TD> 
                                  <TD WIDTH=\"55\" CLASS=\"tabela0_nag2\">&nbsp;<A CLASS=\"tabela0_nag_txt\" HREF=\"baza_filmy-przegladaj-w4a.php?sort=5\">Lektor</A>&nbsp;</TD> 
                                  <TD WIDTH=\"55\" CLASS=\"tabela0_nag2\">&nbsp;<A CLASS=\"tabela0_nag_txt\" HREF=\"baza_filmy-przegladaj-w4a.php?sort=6\">Nośnik</A>&nbsp;</TD> 
                                  <TD WIDTH=\"45\" CLASS=\"tabela0_nag2\">&nbsp;<A CLASS=\"tabela0_nag_txt\" HREF=\"baza_filmy-przegladaj-w4a.php?sort=7\">Rok</A>&nbsp;</TD> 
                                  <TD WIDTH=\"155\" CLASS=\"tabela0_nag2\">&nbsp;<A CLASS=\"tabela0_nag_txt\" HREF=\"baza_filmy-przegladaj-w4a.php?sort=8\">Aktor 1</A>&nbsp;</TD> 
                                  <TD WIDTH=\"155\" CLASS=\"tabela0_nag2\">&nbsp;Aktor 2&nbsp;</TD> 
                              </TR> 
                     "); 
               $iLicznik = 0; $Info = ""; 
               while($Info = @mysqli_fetch_array($SQL_Query)) { 
                 //Wykonuj pętle tak długo dopóki będą pobierane dane z tabeli. 
                 // 
                 //MYSQLI_FETCH_ARRAY() - Zapisuje wiersz wyniku w tablicy 
                 //                       asocjacyjnej, numerycznej lub w obu. 
                 //                       Jest rozszerzoną wersją MYSQL_FETCH_ROW(). 
                 //                       Oprócz zapisywania danych w indeksach 
                 //                       numerycznych, zapisuje je też w indeksach 
                 //                       przyporządkowujących (tzw. asocjacyjnych), 
                 //                       używając nazw pól jako kluczy. 
                 //                       Jeżeli dwie lub więcej kolumn wyniku ma 
                 //                       te same nazwy, ostatnia kolumna będzie brana 
                 //                       pod uwagę. Dostęp do innych kolumn o tej 
                 //                       samej nazwie jest możliwy jedynie przez 
                 //                       indeksowanie numeryczne. 
                   $iLicznik++; //Inkrementacja zawartości zmiennej o wartość 1, tj. numerowanie kolejnego wiersza. 
                   print(" 
                           <TR CLASS=\"wiersz_zaznacz\">
                               <TD WIDTH=\"25\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: right;\">&nbsp;".$iLicznik."&nbsp;</TD> 
                               <TD WIDTH=\"299\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[1]."&nbsp;</TD> 
                               <TD WIDTH=\"299\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[2]."&nbsp;</TD> 
                               <TD WIDTH=\"99\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[3]."&nbsp;</TD> 
                               <TD WIDTH=\"35\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: right;\">&nbsp;".$Info[4]."&nbsp;</TD> 
                               <TD WIDTH=\"55\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: center;\">&nbsp;".$Info[5]."&nbsp;</TD> 
                               <TD WIDTH=\"55\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: center;\">&nbsp;".$Info[6]."&nbsp;</TD> 
                               <TD WIDTH=\"45\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: right;\">&nbsp;".$Info[7]."&nbsp;</TD> 
                               <TD WIDTH=\"155\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[8]."&nbsp;</TD> 
                               <TD WIDTH=\"155\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[9]."&nbsp;</TD> 
                           </TR> 
                         "); 
               } 
               print(" 
                       </TABLE> 
                       </CENTER> 
                     "); 
           } 
         } 
       } 
       @mysqli_close($SQL_Polacz); 
     } 
?> 
<BR/><BR/> 
</DIV> 
</BODY> 
</HTML> 