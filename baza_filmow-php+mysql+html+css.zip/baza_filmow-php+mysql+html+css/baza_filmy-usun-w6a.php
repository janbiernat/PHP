﻿<HTML><HEAD><META CHARSET="utf-8" /> 
<META NAME="keywords" CONTENT="Baza filmów, filmy, baza, baza filmy" /> 
<LINK REL="shortcut icon" HREF="gui/film.ico" /> 
<LINK REL="stylesheet" TYPE="text/css" HREF="gui/style.css" /> 
<TITLE>Baza filmów - Usuń - w6a (c)by Jan T. Biernat</TITLE> 
</HEAD> 
<BODY> 
<DIV ID="strona"> 
<FONT CLASS="info_autor"><B><I>Baza filmów - Usuń - w6a (c)by Jan T. Biernat</I></B></FONT> 
<P ALIGN="center"><BR/><FONT CLASS="tytul"><B><I>Baza filmów</I></B></FONT></P> 
<FORM METHOD="post" ACTION=""> 
<?php 
   //Deklaracja zmiennych tekstowych. 
     $SQL_Polacz = ""; 
     $SQL_Query = ""; 
     $Info = ""; 
     $iLicznik = 0; 
     $SQL_Usun = ""; 
   //Skrypt PHP. 
     $SQL_Polacz = @mysqli_connect('localhost', 'root', ''); 
     if($SQL_Polacz) { 
       if(@mysqli_select_db($SQL_Polacz, "baza_filmow")) { 
         //Usuń wybrany rekord. 
         if((isset($_POST['fkIDusun']) == true) 
         && (isset($_POST['fkRekord']) == true)) { 
           for($I= 0; $I < count($_POST['fkRekord']); $I++) { 
             $SQL_Usun = ""; 
             $SQL_Usun = " 
                           DELETE FROM `filmy` 
                           WHERE `film_id` = '".($_POST['fkRekord'][$I])."' 
                         "; 
             @mysqli_query($SQL_Polacz, $SQL_Usun); 
           } 
         } 
         //Pobranie danych z bazy. 
         $SQL_Query = ""; 
         $SQL_Query = @mysqli_query($SQL_Polacz, ' 
                                                   SELECT DISTINCT `film_id`, 
                                                                   `film_tytul_org`, 
                                                                   `film_tytul_pl`, 
                                                                   `film_gatunek`, 
                                                                   `film_czas_trwania`, 
                                                                   `film_lektor`, 
                                                                   `film_nosnik`, 
                                                                   `film_rok_prod`, 
                                                                   `film_aktor_gl1`, 
                                                                   `film_aktor_gl2` 
                                                   FROM `filmy` 
                                                   ORDER BY `film_tytul_org` ASC 
                                                 '); 
         if($SQL_Query) { 
           if(@mysqli_num_rows($SQL_Query) > 0) { 
             //Jeżeli ilość wierszy zwróconych przez zapytanie 
             //jest większa niż 0, to wykonaj poniższe instrukcje. 
             // 
             //MYSQLI_NUM_ROWS(P) - zwraca liczbę wierszy w wyniku. 
             //                     Instrukcję tę stosuje się tylko 
             //                     przy wykorzystaniu polecenia SELECT. 
             //                     W parametrze P umieszcza się zmienną 
             //                     przechowującą wartość jaką zwróci 
             //                     instrukcja MYSQLI_QUERY. 
               print(" <BR/> 
                       <CENTER> 
                       <TABLE CLASS=\"tabela0\"> 
                              <TR><TD WIDTH=\"25\" CLASS=\"tabela0_nag1\">&nbsp;LP&nbsp;</TD> 
                                  <TD WIDTH=\"277\" CLASS=\"tabela0_nag2\">&nbsp;Tytuł filmu&nbsp;</TD> 
                                  <TD WIDTH=\"277\" CLASS=\"tabela0_nag2\">&nbsp;Tytuł polski filmu&nbsp;</TD> 
                                  <TD WIDTH=\"99\" CLASS=\"tabela0_nag2\">&nbsp;Gatunek&nbsp;</TD> 
                                  <TD WIDTH=\"35\" CLASS=\"tabela0_nag2\">&nbsp;Czas&nbsp;</TD> 
                                  <TD WIDTH=\"55\" CLASS=\"tabela0_nag2\">&nbsp;Lektor&nbsp;</TD> 
                                  <TD WIDTH=\"55\" CLASS=\"tabela0_nag2\">&nbsp;Nośnik&nbsp;</TD> 
                                  <TD WIDTH=\"45\" CLASS=\"tabela0_nag2\">&nbsp;Rok&nbsp;</TD> 
                                  <TD WIDTH=\"155\" CLASS=\"tabela0_nag2\">&nbsp;Aktor 1&nbsp;</TD> 
                                  <TD WIDTH=\"155\" CLASS=\"tabela0_nag2\">&nbsp;Aktor 2&nbsp;</TD> 
                                  <TD WIDTH=\"49\" CLASS=\"tabela0_nag2\">&nbsp;Usuń&nbsp;</TD> 
                              </TR> 
                     "); 
               $iLicznik = 0; $Info = ""; 
               while($Info = @mysqli_fetch_array($SQL_Query)) { 
                 //Wykonuj pętle tak długo dopóki będą pobierane dane z tabeli. 
                 // 
                 //MYSQLI_FETCH_ARRAY() - Zapisuje wiersz wyniku w tablicy 
                 //                       asocjacyjnej, numerycznej lub w obu. 
                 //                       Jest rozszerzoną wersją MYSQL_FETCH_ROW(). 
                 //                       Oprócz zapisywania danych w indeksach 
                 //                       numerycznych, zapisuje je też w indeksach 
                 //                       przyporządkowujących (tzw. asocjacyjnych), 
                 //                       używając nazw pól jako kluczy. 
                 //                       Jeżeli dwie lub więcej kolumn wyniku ma 
                 //                       te same nazwy, ostatnia kolumna będzie brana 
                 //                       pod uwagę. Dostęp do innych kolumn o tej 
                 //                       samej nazwie jest możliwy jedynie przez 
                 //                       indeksowanie numeryczne. 
                   $iLicznik++; //Inkrementacja zawartości zmiennej o wartość 1, tj. numerowanie kolejnego wiersza. 
                   print(" 
                           <TR CLASS=\"wiersz_zaznacz\">
                               <TD WIDTH=\"25\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: right;\">&nbsp;".$iLicznik."&nbsp;</TD> 
                               <TD WIDTH=\"277\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[1]."&nbsp;</TD> 
                               <TD WIDTH=\"277\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[2]."&nbsp;</TD> 
                               <TD WIDTH=\"99\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[3]."&nbsp;</TD> 
                               <TD WIDTH=\"35\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: right;\">&nbsp;".$Info[4]."&nbsp;</TD> 
                               <TD WIDTH=\"55\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: center;\">&nbsp;".$Info[5]."&nbsp;</TD> 
                               <TD WIDTH=\"55\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: center;\">&nbsp;".$Info[6]."&nbsp;</TD> 
                               <TD WIDTH=\"45\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align: right;\">&nbsp;".$Info[7]."&nbsp;</TD> 
                               <TD WIDTH=\"155\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[8]."&nbsp;</TD> 
                               <TD WIDTH=\"155\" CLASS=\"tabela0_wiersz\">&nbsp;".$Info[9]."&nbsp;</TD> 
                               <TD WIDTH=\"49\" CLASS=\"tabela0_wiersz\" STYLE=\"text-align:center;\"> 
                                   <INPUT TYPE=\"checkbox\" VALUE=\"".$Info[0]."\" NAME=\"fkRekord[]\" /> 
                               </TD> 
                           </TR> 
                         "); 
               } 
               print(" 
                       <TR STYLE=\"background-color:white;\"> 
                           <TD CLASS=\"tabela0_wiersz\" COLSPAN=\"11\" STYLE=\"text-align:right;\"> 
                               <INPUT TYPE=\"submit\" NAME=\"fkIDusun\" VALUE=\"Skasuj zaznaczone\" /> 
                               &nbsp;&nbsp;</TD></TR> 
                       </TABLE> 
                       </CENTER> 
                     "); 
           } 
         } 
       } 
       @mysqli_close($SQL_Polacz); 
     } 
?> 
</FORM> 
<BR/><BR/> 
</DIV> 
</BODY> 
</HTML> 